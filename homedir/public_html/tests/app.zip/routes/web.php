<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//website routes
Auth::routes();
Route::get('/', function () {
  return redirect('/adminpanel');
});

Route::get('/clearcache185', function () {
    $clearcache = Artisan::call('cache:clear');
    echo "Cache cleared<br>";

    $clearview = Artisan::call('view:clear');
    echo "View cleared<br>";

    $clearconfig = Artisan::call('config:cache');
    echo "Config cleared<br>";

});


//admin routes
Route::resource('adminpanel/','adminloginController');  
Route::group(['middleware' => ['adminauth:admin']], function () 
{
  Route::resource('adminpanel/users','adminmemberController');
  Route::get('adminpanel/facebookusers','adminmemberController@index2');
  Route::get('adminpanel/googleusers','adminmemberController@index3');
  Route::get('adminpanel/deliveryrequests','adminmemberController@index4');
  Route::get('adminpanel/deliverymembers','adminmemberController@index5');
  
  Route::resource('adminpanel/orders','adminorderController');
  Route::get('adminpanel/revieworders','adminorderController@index2');
  Route::get('adminpanel/acceptorders','adminorderController@index3');
  Route::get('adminpanel/canceledorders','adminorderController@index4');
  Route::get('adminpanel/finishedorders','adminorderController@index5');
  Route::resource('adminpanel/provider','providerController');
  Route::resource('adminpanel/setapp','adminchangelogoController');
  Route::resource('adminpanel/sliders','adminsliderController');   
});

//admin logout
Route::get('logout','adminloginController@destroy');


