<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});


//user Controller routes
Route::post('register','API\userController@register');
Route::post('registerasdeliverman','API\userController@registerasdeliverman');
Route::post('activat_account','API\userController@activat_account');
Route::post('login','API\userController@login');
Route::post('rechangepass','API\userController@rechangepass');
Route::post('profile','API\userController@profile');
Route::post('updateprofile','API\userController@update');
Route::post('forgetpassword','API\userController@forgetpassword');
Route::post('activcode','API\userController@activcode');
Route::post('updatelocation','API\userController@updatelocation');

// order Controller 
Route::post('makeorder','API\orderController@makeorder');
Route::post('deliverycount','API\orderController@deliverycount');
Route::post('deliverorders','API\orderController@deliverorders');
Route::post('applyoffer','API\orderController@applyoffer');
Route::post('myorderoffers','API\orderController@myorderoffers');
Route::post('confirmoffer','API\orderController@confirmoffer');
Route::post('receiveorder','API\orderController@receiveorder');
Route::post('cancelorder','API\orderController@cancelorder');
Route::post('deleteorder','API\orderController@deleteorder');
Route::post('myorders','API\orderController@myorders');
Route::post('mydeliverorders','API\orderController@mydeliverorders');
Route::post('singelorder','API\orderController@singelorder');

//App Setting Controller 
Route::get('settinginfo','API\appsettingController@settingindex');
Route::post('addrate','API\appsettingController@addrate');
Route::get('privacy','API\appsettingController@privacy');
Route::get('policy','API\appsettingController@policy');

