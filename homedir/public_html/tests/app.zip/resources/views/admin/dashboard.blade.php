@extends('admin.include.master')
@section('title') لوحة التحكم @endsection
@section('content')

    <div class=" content-area ">

        <div dir="rtl" class="page-header">
          <h4 class="page-title">لوحة التحكم | إحصائيات الموقع</h4>
        </div>

        <div dir="rtl" class="row row-cards">
          
          <div  class="col-sm-12 col-lg-4">
            <div class="card bg-primary card-img-holder text-white">
              <div class="card-body">
                <h4 class="font-weight-normal  mb-3"> الأعضاء المسجلين بواسطة رقم الجوال
                  <i class="fa fa-user-o fs-30 float-right"></i>
                </h4>
                <h2 class="mb-0">{{$phonemembers}}</h2>
              </div>
            </div>
          </div>

          <div class="col-sm-12 col-lg-4">
            <div class="card bg-primary card-img-holder text-white">
              <div class="card-body">
                <h4 class="font-weight-normal  mb-3"> الأعضاء المسجلين بواسطة الفيس بوك
                  <i class="fa fa-user-o fs-30 float-right"></i>
                </h4>
                <h2 class="mb-0">{{$facebookmembers}}</h2>
              </div>
            </div>
          </div>

          <div class="col-sm-12 col-lg-4">
            <div class="card bg-primary card-img-holder text-white">
              <div class="card-body">
                <h4 class="font-weight-normal  mb-3"> الأعضاء المسجلين بواسطة جوجل
                  <i class="fa fa-user-o fs-30 float-right"></i>
                </h4>
                <h2 class="mb-0">{{$googlemembers}}</h2>
              </div>
            </div>
          </div>

          <div class="col-sm-12 col-lg-4">
            <div class="card bg-primary card-img-holder text-white">
              <div class="card-body">
                <h4 class="font-weight-normal  mb-3"> طلبات تسجيل المندوبين
                  <i class="fa fa-user-o fs-30 float-right"></i>
                </h4>
                <h2 class="mb-0">{{$deliveryrequests}}</h2>
              </div>
            </div>
          </div>

          <div class="col-sm-12 col-lg-4">
            <div class="card bg-primary card-img-holder text-white">
              <div class="card-body">
                <h4 class="font-weight-normal  mb-3"> المندوبين
                  <i class="fa fa-user-o fs-30 float-right"></i>
                </h4>
                <h2 class="mb-0">{{$deliverymembers}}</h2>
              </div>
            </div>
          </div>

          <div class="col-sm-12 col-lg-4">
            <div class="card bg-primary card-img-holder text-white">
              <div class="card-body">
                <h4 class="font-weight-normal  mb-3"> الطلبات الجديدة
                  <i class="fa fa-cubes  fs-30 float-right"></i>
                </h4>
                <h2 id="neworders" class="mb-0">{{$neworders}}</h2>
              </div>
            </div>
          </div>

          <div class="col-sm-12 col-lg-4">
            <div class="card bg-primary card-img-holder text-white">
              <div class="card-body">
                <h4 class="font-weight-normal  mb-3"> الطلبات بعد المراجعة
                  <i class="fa fa-cubes  fs-30 float-right"></i>
                </h4>
                <h2 id="revieworders" class="mb-0">{{$revieworders}}</h2>
              </div>
            </div>
          </div>

          <div class="col-sm-12 col-lg-4">
            <div class="card bg-primary card-img-holder text-white">
              <div class="card-body">
                <h4 class="font-weight-normal  mb-3"> الطلبات المؤكدة
                  <i class="fa fa-cubes  fs-30 float-right"></i>
                </h4>
                <h2 id="acceptorders" class="mb-0">{{$acceptorders}}</h2>
              </div>
            </div>
          </div>

          <div class="col-sm-12 col-lg-4">
            <div class="card bg-primary card-img-holder text-white">
              <div class="card-body">
                <h4 class="font-weight-normal  mb-3"> الطلبات الملغية
                  <i class="fa fa-cubes  fs-30 float-right"></i>
                </h4>
                <h2 id="cancelorders" class="mb-0">{{$cancelorders}}</h2>
              </div>
            </div>
          </div>
          
          <div class="col-sm-12 col-lg-4">
            <div class="card bg-primary card-img-holder text-white">
              <div class="card-body">
                <h4 class="font-weight-normal  mb-3"> الطلبات المنتهية
                  <i class="fa fa-cubes  fs-30 float-right"></i>
                </h4>
                <h2 id="finishedorders" class="mb-0">{{$finishedorders}}</h2>
              </div>
            </div>
          </div>


        </div>

    </div>

    <script src="https://js.pusher.com/5.1/pusher.min.js"></script>
    <script type="text/javascript">
        Pusher.logToConsole = true;
        var pusher = new Pusher('dd379b92851a0dcb82e6', {
          cluster: 'eu',
          forceTLS: true
        });
          // Subscribe to the channel we specified in our Laravel Event
          var channel = pusher.subscribe('order-count');

          // Bind a function to a Event (the full Laravel class)

          channel.bind('App\\Events\\orderevent', function(data) 
          {
              $("#neworders").html(data.neworderscount);
              $("#revieworders").html(data.revieworderscount);
              $("#acceptorders").html(data.acceptorderscount);
              $("#cancelorders").html(data.cancelorderscount);
              $("#finishedorders").html(data.finishedorderscount);
          });
    </script>

@endsection 