@extends('admin.include.master')
@section('title') لوحة التحكم | إعدادات الموقع @endsection
@section('content')

  <div class="my-3 my-md-5">
    <div class="container">
      <div dir="rtl" class="page-header">
        <h4 class="page-title">إعدادات الموقع</h4>
      </div>
      
    <div class="row">
        <div class="col-12">
        {{ Form::open(array('method' => 'PATCH','files' => true,'class' => 'card','url' =>'adminpanel/setapp/'.$changelogo->id )) }}
            <div dir="rtl" class="card-header">
              <h3 class="card-title">تغيير اللوجو</h3>
            </div>

            <div class="card-body">
              <div class="row">

                <div class="col-md-6 col-lg-6">
                    <label class="form-label">صورة اللوجو</label>
                    <div style="margin-bottom: 0;" class="login-logo">
                        <img class="img-thumbnail" style="height: 10%;" src="{{asset('users/images/'.$changelogo->logo)}}" alt="Logo"><br>
                    </div>
                </div>

                <div class="col-md-6 col-lg-6">

                    <div class="form-group">
                        <label class="form-label">لوجو  الموقع</label>
                        <input style="width:100%;" type="file" class="form-control" name="logo">
                        @if ($errors->has('logo'))
                        <div style="color: crimson;font-size: 18px;" class="error">{{ $errors->first('logo') }}</div>
                        @endif
                    </div>

                  <div class="btn-list text-center">
                    <button type="submit" class="btn btn-primary col-md-4">تغيير</button>
                  </div>

                </div>

              </div>
            </div>

        {!! Form::close() !!}
      </div>
    </div>
    
    <div class="row">
        <div class="col-12">
        {{ Form::open(array('method' => 'PATCH','files' => true,'class' => 'card','url' =>'adminpanel/setapp/'.$changelogo->id )) }}
            <input type="hidden" name="splach">
            <div dir="rtl" class="card-header">
              <h3 class="card-title">تغيير الصورة الافتتاحية</h3>
            </div>

            <div class="card-body">
              <div class="row">

                <div class="col-md-6 col-lg-6">
                    <label class="form-label">الصورة الإفتتاحية</label>
                    <div style="margin-bottom: 0;" class="login-logo">
                        <img class="img-thumbnail" style="height: 10%;" src="{{asset('users/images/'.$changelogo->splach)}}" alt="splach"><br>
                    </div>
                </div>

                <div class="col-md-6 col-lg-6">

                    <div class="form-group">
                        <label class="form-label">الصورة الإفتتاحية</label>
                        <input style="width:100%;" type="file" class="form-control" name="splach">
                        @if ($errors->has('splach'))
                        <div style="color: crimson;font-size: 18px;" class="error">{{ $errors->first('splach') }}</div>
                        @endif
                    </div>

                  <div class="btn-list text-center">
                    <button type="submit" class="btn btn-primary col-md-4">تغيير</button>
                  </div>

                </div>

              </div>
            </div>

        {!! Form::close() !!}
      </div>
    </div>
    
    <div class="row">
        <div class="col-12">
        {{ Form::open(array('method' => 'PATCH','files' => true,'class' => 'card','url' =>'adminpanel/setapp/'.$changelogo->id )) }}
            <input type="hidden" name="splachvideo">
            <div dir="rtl" class="card-header">
              <h3 class="card-title">تغيير الفيديو الإفتتاحى </h3>
            </div>

            <div class="card-body">
              <div class="row">

                <div class="col-md-6 col-lg-6">
                    <label class="form-label">الفيديو الإفتتاحى</label>
                    <div style="margin-bottom: 0;" class="login-logo">
                        <video width="320" height="240" controls>
                          <source src="{{asset('users/images/'.$changelogo->splachvideo)}}" type="video/mp4">
                        </video>
                    </div>
                </div>

                <div class="col-md-6 col-lg-6">

                    <div class="form-group">
                        <label class="form-label">الفيديو الإفتتاحى</label>
                        <input style="width:100%;" type="file" class="form-control" name="splachvideo">
                        @if ($errors->has('splachvideo'))
                        <div style="color: crimson;font-size: 18px;" class="error">{{ $errors->first('splachvideo') }}</div>
                        @endif
                    </div>

                  <div class="btn-list text-center">
                    <button type="submit" class="btn btn-primary col-md-4">تغيير</button>
                  </div>

                </div>

              </div>
            </div>

        {!! Form::close() !!}
      </div>
    </div>
    
    <div class="row">
        <div class="col-12">
        {{ Form::open(array('method' => 'PATCH','files' => true,'class' => 'card','url' =>'adminpanel/setapp/'.$changelogo->id )) }}
            <input type="hidden" name="image">
            <div dir="rtl" class="card-header">
              <h3 class="card-title">تغيير الصورة الداخلية</h3>
            </div>

            <div class="card-body">
              <div class="row">

                <div class="col-md-6 col-lg-6">
                    <label class="form-label">الصورة الداخلية</label>
                    <div style="margin-bottom: 0;" class="login-logo">
                        <img class="img-thumbnail" style="height: 10%;" src="{{asset('users/images/'.$changelogo->image)}}" alt="splach"><br>
                    </div>
                </div>

                <div class="col-md-6 col-lg-6">

                    <div class="form-group">
                        <label class="form-label">الصورة الداخلية</label>
                        <input style="width:100%;" type="file" class="form-control" name="image">
                        @if ($errors->has('image'))
                        <div style="color: crimson;font-size: 18px;" class="error">{{ $errors->first('image') }}</div>
                        @endif
                    </div>

                  <div class="btn-list text-center">
                    <button type="submit" class="btn btn-primary col-md-4">تغيير</button>
                  </div>

                </div>

              </div>
            </div>

        {!! Form::close() !!}
      </div>
    </div>
    
    
    </div>
  </div>

@endsection