@extends('admin/include/master')
@section('title') لوحة التحكم | الطلبات بعد المراجعة  @endsection
@section('content')
<style>
form , button{
  float   : left;
  padding : 1%;
}
</style>

  <div class="my-3 my-md-5">
    <div class="container">
        <div dir="rtl" class="page-header">
            <h4 class="page-title">الطلبات بعد المراجعة</h4>
        </div>
    
      <div class="row">
        <div class="col-md-12 col-lg-12">
          <div class="card">

            <div dir="rtl" class="card-header">
              <div  class="card-title">كل الطلبات بعد المراجعة</div>
            </div>

            <div class="card-body">
            @if(count($allorders) != 0)
              <div class="table-responsive">
                <table dir="rtl" id="example1" class="table card-table table-vcenter text-nowrap">
                  <thead>
                    <tr>
                        <th>إسم العميل</th>
                        <th>رقم الجوال</th>
                        <th>العنوان</th>
                        <th></th>
                    </tr>
                  </thead>
                    <tbody>
                        @foreach($allorders as $order)
                        <?php 
                            $deliverinfo = DB::table('members')->where('id',$order->user_id)->first();
                            $buyerinfo   = DB::table('members')->where('id',$order->buyer_id)->first();
                        ?>
                        <tr>
                            <td> @if($buyerinfo) {{$buyerinfo->phone}} @endif</td>
                            <td>{{$order->address}}</td>
                            <td class="text-center">
                                {{ Form::open(array('method' => 'DELETE',"onclick"=>"return confirm('هل انت متأكد')",'files' => true,'url' => array('adminpanel/orders/'.$order->id))) }}
                                    <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> حذف</button>
                                {!! Form::close() !!}
                                <button style="margin-top: 3px;" class="btn btn-info btn-sm" data-toggle="modal" data-target="#previewmodal{{$order->id}}"><i class="fa fa-eye"></i> مشاهدة تفاصيل الطلب</button>
                            </td>
                        </tr>

                        <div id="previewmodal{{$order->id}}" class="modal fade show" style="display: none; padding-right: 6px;">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">

                                  <div dir="rtl" class="modal-header pd-x-20">
                                    <h3 class="modal-title">مشاهدة تفاصيل الطلب</h3>
                                  </div>

                                  <div  class="modal-body">
                                      <h4 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">وصف الطلب</h4>
                                      <p  style="text-align: right;border: 2px solid #17B794;padding: 1%;" class="">{{$order->order}}</p>
                                      @if($order->guides != null)
                                          <h4 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">إرشادات إضافية</h4>
                                          <p  style="text-align: right;" class="">{{$order->guides}}</p>
                                      @endif

                                      <h5 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">تكلفة الطلب : <span>{{$order->price}} ريال</span> </h5> 
                                      <h5 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">تكلفة التوصيل : <span>{{$order->delivercost}} ريال</span> </h5> 


                                      <div style="float: right;" class="col-md-6">
                                            <h4 style="text-align:end">بيانات العميل</h4>
                                            <h5 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">إسم العميل : <span>{{$order->name}}</span> </h5> 
                                            <h5 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">رقم الجوال : <span>{{$order->phone}}</span> </h5> 
                                            <h5 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">العنوان    : <span>{{$order->address}} - رقم بناية {{$order->buildingNo}} رقم طابق {{$order->floorNo}} رقم شقة {{$order->flatNo}}</span> </h5> 
                                      </div>
                                      
                                      <div style="float: left;" class="col-md-6">
                                          @if($deliverinfo)
                                            <h4 style="text-align:end">بيانات المندوب</h4>
                                            <h5 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">إسم العميل : <a href="{{asset('adminpanel/users/'.$deliverinfo->id)}}">{{$deliverinfo->name}}</a> </h5> 
                                            <h5 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">رقم الجوال : <span>{{$deliverinfo->phone}}</span> </h5> 
                                          @endif
                                      </div>
                                  </div>

                                  <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">إلغاء</button>
                                  </div>

                            </div>
                          </div>
                        </div>

                        @endforeach
                    </tbody>
                </table>
                
              </div>
            @else 
                <p class="text-center">لا يوجد طلبات تمت مراجعتها حاليا  </p>
            @endif
            </div>

          </div>

        </div>
      </div>

    </div>
  </div>

@endsection
