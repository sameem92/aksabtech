@extends('admin/include/master')
@section('title') لوحة التحكم | الأعضاء   @endsection
@section('content')
<style>
form{float   : left;padding : 1%;}
</style>

  <div class="my-3 my-md-5">
    <div class="container">
        <div dir="rtl" class="page-header">
            <h4 class="page-title">الأعضاء المسجلين بواسطة رقم الجوال</h4>
        </div>
    
      <div class="row">
        <div class="col-md-12 col-lg-12">
          <div class="card">

            <div dir="rtl" class="card-header">
              <div  class="card-title">كل الأعضاء المسجلين بواسطة رقم الجوال</div>
            </div>

            <div class="card-body">
            @if(count($phoneusers) != 0)
              <div class="table-responsive">
                <table dir="rtl" id="example1" class="table card-table table-vcenter text-nowrap">
                  <thead>
                    <tr>
                        <th>رقم الجوال</th>
                        <th></th>
                    </tr>
                  </thead>
                    <tbody>
                        @foreach($phoneusers as $user)
                        <tr>
                            <td>{{$user->phone}}</td>
                            <td class="text-center">
                                {{ Form::open(array('method' => 'DELETE',"onclick"=>"return confirm('هل انت متأكد')",'files' => true,'url' => array('adminpanel/users/'.$user->id))) }}
                                    <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> حذف</button>
                                {!! Form::close() !!}
                                {{ Form::open(array('method' => 'patch',"onclick"=>"return confirm('هل انت متأكد')",'files' => true,'url' => array('adminpanel/users/'.$user->id))) }}
                                    <input type="hidden" name="suspensed">
                                    @if($user->suspensed == 0)
                                    <button type="submit" class="btn btn-lime btn-sm"><i class="fa fa-lock"></i>  تعطيل</button>
                                    @else
                                    <button type="submit" class="btn btn-lime btn-sm"><i class="fa fa-unlock"></i>  تفعيل</button>
                                    @endif
                                {!! Form::close() !!}
                                <form><a href='{{asset("adminpanel/users/".$user->id)}}' class="btn btn-info btn-sm"><i class="fa fa-eye"></i> مشاهدة</a></form>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
                
              </div>
            @else 
                <p class="text-center">لا يوجد أعضاء  </p>
            @endif
            </div>

          </div>

        </div>
      </div>

    </div>
  </div>

@endsection
