@extends('admin/include/master')
@section('title') لوحة التحكم | مشاهدة بيانات المندوب @endsection
@section('content')  


    <div class="my-3 my-md-5">
        <div class="container">
            <div dir="rtl" class="page-header">
                <h4 class="page-title">بيانات المندوب</h4>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-profile " style="background-image: url({{asset('admin/assets/images/photos/12.jpg')}});    background-position: center; background-size:cover;">
                        <div class="card-body text-center">
                            @if($showuser->role == 1)
                                <img class="card-profile-img" src="{{asset('users/images/defaultdeliverman.png')}}" alt="defaultdeliverman Image">
                            @elseif($showuser->role == 0)
                                <img class="card-profile-img" src="{{asset('users/images/defaultuser.png')}}" alt="defaultuser Image">
                            @endif
                            <h3 class="mb-3 text-white">{{$showuser->name}}</h3>
                            @if($showuser->role == 0)
                               {{ Form::open(array('method' => 'patch',"onclick"=>"return confirm('هل انت متأكد')",'files' => true,'url' => array('adminpanel/users/'.$showuser->id))) }}
                                    <input type="hidden" name="suspensed">
                                    @if($showuser->suspensed == 0)
                                        <button type="submit" class="btn btn-lime btn-sm"><i class="fa fa-lock"></i>  تعطيل</button>
                                    @else
                                        <button type="submit" class="btn btn-lime btn-sm"><i class="fa fa-unlock"></i>  تفعيل</button>
                                    @endif
                                {!! Form::close() !!}
                            @elseif($showuser->role == 1)
                                @if($showuser->activate == 1)
                                    <a href="{{asset("adminpanel/users/".$showuser->id)}}/edit" class="btn btn-warning btn-sm"><i class="fa fa-pencil" aria-hidden="true"></i>تعديل</a>
                                @else 
                                    <button class="btn btn-success btn-sm" data-toggle="modal" data-target="#previewmodal{{$showuser->id}}"> <i class="fa fa-check"></i> قبول</button>
                                    <div id="previewmodal{{$showuser->id}}" class="modal fade show" style="display: none; padding-right: 6px;">
                                        <div class="modal-dialog modal-lg" role="document">
                                            <div class="modal-content ">
                                            <div dir="rtl" class="modal-header pd-x-20">
                                                <h3 class="modal-title">تفعيل حساب المندوب {{$showuser->name}} </h3>
                                            </div>
                                            {!! Form::open(array('method' => 'patch','url' =>'adminpanel/users/'.$showuser->id)) !!}
                                                <input type="hidden" name="activation">
                                                <div  class="modal-body pd-20">

                                                    <div style="text-align: right;" class="form-group">
                                                        <label class="form-control-label"> كلمة المرور </label>
                                                        <input type="password" class="form-control" name="password" required>
                                                        @if ($errors->has('password'))
                                                        <div style="color: crimson;font-size: 18px;" class="error">{{ $errors->first('password') }}</div>
                                                        @endif
                                                    </div>

                                                    <div style="text-align: right;" class="form-group">
                                                        <label class="form-control-label"> إعادة كلمة المرور </label>
                                                        <input type="password" class="form-control" name="confirmpassword" required>
                                                        @if ($errors->has('confirmpassword'))
                                                        <div style="color: crimson;font-size: 18px;" class="error">{{ $errors->first('confirmpassword') }}</div>
                                                        @endif
                                                    </div>

                                                </div>

                                                <div class="modal-footer">
                                                    <button type="submit" class="btn btn-primary">تفعيل</button>
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">إلغاء</button>
                                                </div>
                                            {!! Form::close() !!}
                                            </div>
                                        </div>
                                    </div>
                                @endif
                            @endif
                            
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <div class="card p-5 ">
                        <div class="card-title">
                            المعلومات الشخصية
                        </div>
                        <div class="media-list">
                            
                            <div class="media mt-1 pb-2">
                                <div class="mediaicon">
                                    <i class="fa fa-phone" aria-hidden="true"></i>
                                </div>
                                <div class="media-body ml-5 mt-1">
                                    <h6 class="mediafont text-dark">رقم الجوال</h6>
                                    <span class="d-block">{{$showuser->phone}}</span>
                                </div>
                            </div>
                            
                            <div class="media mt-1 pb-2">
                                <div class="mediaicon">
                                    <i class="fa fa-phone" aria-hidden="true"></i>
                                </div>
                                <div class="media-body ml-5 mt-1">
                                    <h6 class="mediafont text-dark">رقم الهوية</h6>
                                    <span class="d-block">{{$showuser->idNo}}</span>
                                </div>
                            </div>
                            
                            <div class="media mt-1 pb-2">
                                <div class="mediaicon">
                                    <i class="fa fa-phone" aria-hidden="true"></i>
                                </div>
                                <div class="media-body ml-5 mt-1">
                                    <h6 class="mediafont text-dark">رقم اللوحة</h6>
                                    <span class="d-block">{{$showuser->plateNo}}</span>
                                </div>
                            </div>

                            
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <div class="card-box tilebox-one">
                                <i class="icon-layers float-right text-muted"><i class="fa fa-cubes text-primary" aria-hidden="true"></i></i>
                                <h6 class="text-drak text-uppercase mt-0">الطلبات بعد المراجعة</h6>
                                <h2 class="m-b-20">{{count($revieworders)}}</h2>
                            </div>
                        </div>
					</div>

                    
                    <div class="card">
                        <div class="card-body">
                            <div class="card-box tilebox-one">
                                <i class="icon-layers float-right text-muted"><i class="fa fa-cubes text-primary" aria-hidden="true"></i></i>
                                <h6 class="text-drak text-uppercase mt-0">الطلبات المؤكدة</h6>
                                <h2 class="m-b-20">{{count($acceptorders)}}</h2>
                            </div>
                        </div>
					</div>

                    
                    <div class="card">
                        <div class="card-body">
                            <div class="card-box tilebox-one">
                                <i class="icon-layers float-right text-muted"><i class="fa fa-cubes text-primary" aria-hidden="true"></i></i>
                                <h6 class="text-drak text-uppercase mt-0">الطلبات الملغية</h6>
                                <h2 class="m-b-20">{{count($cancelorders)}}</h2>
                            </div>
                        </div>
					</div>
					
					<div class="card">
                        <div class="card-body">
                            <div class="card-box tilebox-one">
                                <i class="icon-layers float-right text-muted"><i class="fa fa-cubes text-primary" aria-hidden="true"></i></i>
                                <h6 class="text-drak text-uppercase mt-0">الطلبات المنتهية</h6>
                                <h2 class="m-b-20">{{count($finishedorders)}}</h2>
                            </div>
                        </div>
					</div>

                </div>
                
                <div class="col-lg-8">

                    <div class="card">
                        <div dir="rtl" class="card-header">
                            <div  class="card-title">الطلبات بعد المراجعة</div>
                        </div>

                        <div class="card-body">
                            @if(count($revieworders) != 0)
                            <div class="table-responsive">
                                <table dir="rtl" id="example1" class="table card-table table-vcenter text-nowrap">
                                <thead>
                                    <tr>
                                        <th>إسم العميل</th>
                                        <th>رقم الجوال</th>
                                        <th>تكلفة الطلب</th>
                                        <th>تكلفة التوصيل</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                    <tbody>
                                        @foreach($revieworders as $order)
                                        <?php $deliverinfo = DB::table('members')->where('id',$order->user_id)->first(); ?>
                                        <tr>
                                            <td>{{$order->name}}</td>
                                            <td>{{$order->phone}}</td>
                                            <td>{{$order->price}} ريال</td>
                                            <td>{{$order->delivercost}} ريال</td>
                                            <td class="text-center">
                                                {{ Form::open(array('method' => 'DELETE',"onclick"=>"return confirm('هل انت متأكد')",'files' => true,'url' => array('adminpanel/orders/'.$order->id))) }}
                                                    <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> حذف</button>
                                                {!! Form::close() !!}
                                                <button style="margin-top: 3px;" class="btn btn-info btn-sm" data-toggle="modal" data-target="#previewmodal{{$order->id}}"><i class="fa fa-eye"></i> مشاهدة تفاصيل الطلب</button>
                                            </td>
                                        </tr>

                                        <div id="previewmodal{{$order->id}}" class="modal fade show" style="display: none; padding-right: 6px;">
                                        <div class="modal-dialog modal-lg" role="document">
                                            <div class="modal-content">

                                                <div dir="rtl" class="modal-header pd-x-20">
                                                    <h3 class="modal-title">مشاهدة تفاصيل الطلب</h3>
                                                </div>

                                                <div  class="modal-body">
                                                    <h4 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">وصف الطلب</h4>
                                                    <p  style="text-align: right;border: 2px solid #17B794;padding: 1%;" class="">{{$order->order}}</p>
                                                    @if($order->guides != null)
                                                        <h4 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">إرشادات إضافية</h4>
                                                        <p  style="text-align: right;" class="">{{$order->guides}}</p>
                                                    @endif

                                                    <h5 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">تكلفة الطلب : <span>{{$order->price}} ريال</span> </h5> 
                                                    <h5 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">تكلفة التوصيل : <span>{{$order->delivercost}} ريال</span> </h5> 


                                                    <div style="float: right;" class="col-md-6">
                                                            <h4 style="text-align:end">بيانات العميل</h4>
                                                            <h5 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">إسم العميل : <span>{{$order->name}}</span> </h5> 
                                                            <h5 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">رقم الجوال : <span>{{$order->phone}}</span> </h5> 
                                                            <h5 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">العنوان    : <span>{{$order->address}} - رقم بناية {{$order->buildingNo}} رقم طابق {{$order->floorNo}} رقم شقة {{$order->flatNo}}</span> </h5> 
                                                    </div>
                                                    
                                                    <div style="float: left;" class="col-md-6">
                                                        @if($deliverinfo)
                                                            <h4 style="text-align:end">بيانات المندوب</h4>
                                                            <h5 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">إسم العميل : <span>{{$deliverinfo->name}}</span> </h5> 
                                                            <h5 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">رقم الجوال : <span>{{$deliverinfo->phone}}</span> </h5> 
                                                        @endif
                                                    </div>
                                                </div>

                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">إلغاء</button>
                                                </div>

                                            </div>
                                        </div>
                                        </div>

                                        @endforeach
                                    </tbody>
                                </table>
                                
                            </div>
                            @else 
                                <p class="text-center">لا يوجد طلبات تمت مراجعتها حاليا  </p>
                            @endif
                        </div>
                    </div>

                    <div class="card">
                        <div dir="rtl" class="card-header">
                            <div  class="card-title">الطلبات المؤكدة</div>
                        </div>

                        <div class="card-body">
                            @if(count($acceptorders) != 0)
                            <div class="table-responsive">
                                <table dir="rtl" id="example1" class="table card-table table-vcenter text-nowrap">
                                <thead>
                                    <tr>
                                        <th>إسم العميل</th>
                                        <th>رقم الجوال</th>
                                        <th>تكلفة الطلب</th>
                                        <th>تكلفة التوصيل</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                    <tbody>
                                        @foreach($acceptorders as $order)
                                        <?php $deliverinfo = DB::table('members')->where('id',$order->user_id)->first(); ?>
                                        <tr>
                                            <td>{{$order->name}}</td>
                                            <td>{{$order->phone}}</td>
                                            <td>{{$order->price}} ريال</td>
                                            <td>{{$order->delivercost}} ريال</td>
                                            <td class="text-center">
                                                {{ Form::open(array('method' => 'DELETE',"onclick"=>"return confirm('هل انت متأكد')",'files' => true,'url' => array('adminpanel/orders/'.$order->id))) }}
                                                    <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> حذف</button>
                                                {!! Form::close() !!}
                                                <button style="margin-top: 3px;" class="btn btn-info btn-sm" data-toggle="modal" data-target="#previewmodal{{$order->id}}"><i class="fa fa-eye"></i> مشاهدة تفاصيل الطلب</button>
                                            </td>
                                        </tr>

                                        <div id="previewmodal{{$order->id}}" class="modal fade show" style="display: none; padding-right: 6px;">
                                        <div class="modal-dialog modal-lg" role="document">
                                            <div class="modal-content">

                                                <div dir="rtl" class="modal-header pd-x-20">
                                                    <h3 class="modal-title">مشاهدة تفاصيل الطلب</h3>
                                                </div>

                                                <div  class="modal-body">
                                                    <h4 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">وصف الطلب</h4>
                                                    <p  style="text-align: right;border: 2px solid #17B794;padding: 1%;" class="">{{$order->order}}</p>
                                                    @if($order->guides != null)
                                                        <h4 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">إرشادات إضافية</h4>
                                                        <p  style="text-align: right;" class="">{{$order->guides}}</p>
                                                    @endif

                                                    <h5 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">تكلفة الطلب : <span>{{$order->price}} ريال</span> </h5> 
                                                    <h5 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">تكلفة التوصيل : <span>{{$order->delivercost}} ريال</span> </h5> 


                                                    <div style="float: right;" class="col-md-6">
                                                            <h4 style="text-align:end">بيانات العميل</h4>
                                                            <h5 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">إسم العميل : <span>{{$order->name}}</span> </h5> 
                                                            <h5 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">رقم الجوال : <span>{{$order->phone}}</span> </h5> 
                                                            <h5 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">العنوان    : <span>{{$order->address}} - رقم بناية {{$order->buildingNo}} رقم طابق {{$order->floorNo}} رقم شقة {{$order->flatNo}}</span> </h5> 
                                                    </div>
                                                    
                                                    <div style="float: left;" class="col-md-6">
                                                        @if($deliverinfo)
                                                            <h4 style="text-align:end">بيانات المندوب</h4>
                                                            <h5 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">إسم العميل : <span>{{$deliverinfo->name}}</span> </h5> 
                                                            <h5 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">رقم الجوال : <span>{{$deliverinfo->phone}}</span> </h5> 
                                                        @endif
                                                    </div>
                                                </div>

                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">إلغاء</button>
                                                </div>

                                            </div>
                                        </div>
                                        </div>
                                            <?php 
                                                $pricetotal       += $order->price;
                                                $delivercosttotal += $order->delivercost;
                                            ?>
                                        @endforeach

                                            <h5 style="text-align:right;">إجمالى تكلفة الطلبات : <span style="color:#17B794;">{{$pricetotal}} ريال</span> </h5>
                                            <h5 style="text-align:right;">إجمالى تكلفة التوصيل : <span style="color:#17B794;" > {{$delivercosttotal}} ريال </span> </h5>
                                    </tbody>
                                </table>
                                
                            </div>
                            @else 
                                <p class="text-center">لا يوجد طلبات مؤكدة حاليا  </p>
                            @endif
                        </div>
                    </div>
                    
                    <div class="card">
                        <div dir="rtl" class="card-header">
                            <div  class="card-title">الطلبات الملغية</div>
                        </div>

                        <div class="card-body">
                            @if(count($cancelorders) != 0)
                            <div class="table-responsive">
                                <table dir="rtl" id="example1" class="table card-table table-vcenter text-nowrap">
                                <thead>
                                    <tr>
                                        <th>إسم العميل</th>
                                        <th>رقم الجوال</th>
                                        <th>تكلفة الطلب</th>
                                        <th>تكلفة التوصيل</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                    <tbody>
                                        @foreach($cancelorders as $order)
                                        <?php $deliverinfo = DB::table('members')->where('id',$order->user_id)->first(); ?>
                                        <tr>
                                            <td>{{$order->name}}</td>
                                            <td>{{$order->phone}}</td>
                                            <td>{{$order->price}} ريال</td>
                                            <td>{{$order->delivercost}} ريال</td>
                                            <td class="text-center">
                                                {{ Form::open(array('method' => 'DELETE',"onclick"=>"return confirm('هل انت متأكد')",'files' => true,'url' => array('adminpanel/orders/'.$order->id))) }}
                                                    <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> حذف</button>
                                                {!! Form::close() !!}
                                                <button style="margin-top: 3px;" class="btn btn-info btn-sm" data-toggle="modal" data-target="#previewmodal{{$order->id}}"><i class="fa fa-eye"></i> مشاهدة تفاصيل الطلب</button>
                                            </td>
                                        </tr>

                                        <div id="previewmodal{{$order->id}}" class="modal fade show" style="display: none; padding-right: 6px;">
                                        <div class="modal-dialog modal-lg" role="document">
                                            <div class="modal-content">

                                                <div dir="rtl" class="modal-header pd-x-20">
                                                    <h3 class="modal-title">مشاهدة تفاصيل الطلب</h3>
                                                </div>

                                                <div  class="modal-body">
                                                    <h4 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">وصف الطلب</h4>
                                                    <p  style="text-align: right;border: 2px solid #17B794;padding: 1%;" class="">{{$order->order}}</p>
                                                    @if($order->guides != null)
                                                        <h4 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">إرشادات إضافية</h4>
                                                        <p  style="text-align: right;" class="">{{$order->guides}}</p>
                                                    @endif

                                                    <h5 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">تكلفة الطلب : <span>{{$order->price}} ريال</span> </h5> 
                                                    <h5 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">تكلفة التوصيل : <span>{{$order->delivercost}} ريال</span> </h5> 


                                                    <div style="float: right;" class="col-md-6">
                                                            <h4 style="text-align:end">بيانات العميل</h4>
                                                            <h5 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">إسم العميل : <span>{{$order->name}}</span> </h5> 
                                                            <h5 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">رقم الجوال : <span>{{$order->phone}}</span> </h5> 
                                                            <h5 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">العنوان    : <span>{{$order->address}} - رقم بناية {{$order->buildingNo}} رقم طابق {{$order->floorNo}} رقم شقة {{$order->flatNo}}</span> </h5> 
                                                    </div>
                                                    
                                                    <div style="float: left;" class="col-md-6">
                                                        @if($deliverinfo)
                                                            <h4 style="text-align:end">بيانات المندوب</h4>
                                                            <h5 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">إسم العميل : <span>{{$deliverinfo->name}}</span> </h5> 
                                                            <h5 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">رقم الجوال : <span>{{$deliverinfo->phone}}</span> </h5> 
                                                        @endif
                                                    </div>
                                                </div>

                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">إلغاء</button>
                                                </div>

                                            </div>
                                        </div>
                                        </div>

                                        @endforeach
                                    </tbody>
                                </table>
                                
                            </div>
                            @else 
                                <p class="text-center">لا يوجد طلبات ملغية حاليا  </p>
                            @endif
                        </div>
                    </div>
                    
                    <div class="card">
                        <div dir="rtl" class="card-header">
                            <div  class="card-title">الطلبات المنتهية</div>
                        </div>

                        <div class="card-body">
                            @if(count($finishedorders) != 0)
                            <div class="table-responsive">
                                <table dir="rtl" id="example1" class="table card-table table-vcenter text-nowrap">
                                <thead>
                                    <tr>
                                        <th>إسم العميل</th>
                                        <th>رقم الجوال</th>
                                        <th>تكلفة الطلب</th>
                                        <th>تكلفة التوصيل</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                    <tbody>
                                        @foreach($finishedorders as $order)
                                        <?php $deliverinfo = DB::table('members')->where('id',$order->user_id)->first(); ?>
                                        <tr>
                                            <td>{{$order->name}}</td>
                                            <td>{{$order->phone}}</td>
                                            <td>{{$order->price}} ريال</td>
                                            <td>{{$order->delivercost}} ريال</td>
                                            <td class="text-center">
                                                {{ Form::open(array('method' => 'DELETE',"onclick"=>"return confirm('هل انت متأكد')",'files' => true,'url' => array('adminpanel/orders/'.$order->id))) }}
                                                    <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> حذف</button>
                                                {!! Form::close() !!}
                                                <button style="margin-top: 3px;" class="btn btn-info btn-sm" data-toggle="modal" data-target="#previewmodal{{$order->id}}"><i class="fa fa-eye"></i> مشاهدة تفاصيل الطلب</button>
                                            </td>
                                        </tr>

                                        <div id="previewmodal{{$order->id}}" class="modal fade show" style="display: none; padding-right: 6px;">
                                        <div class="modal-dialog modal-lg" role="document">
                                            <div class="modal-content">

                                                <div dir="rtl" class="modal-header pd-x-20">
                                                    <h3 class="modal-title">مشاهدة تفاصيل الطلب</h3>
                                                </div>

                                                <div  class="modal-body">
                                                    <h4 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">وصف الطلب</h4>
                                                    <p  style="text-align: right;border: 2px solid #17B794;padding: 1%;" class="">{{$order->order}}</p>
                                                    @if($order->guides != null)
                                                        <h4 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">إرشادات إضافية</h4>
                                                        <p  style="text-align: right;" class="">{{$order->guides}}</p>
                                                    @endif

                                                    <h5 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">تكلفة الطلب : <span>{{$order->price}} ريال</span> </h5> 
                                                    <h5 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">تكلفة التوصيل : <span>{{$order->delivercost}} ريال</span> </h5> 


                                                    <div style="float: right;" class="col-md-6">
                                                            <h4 style="text-align:end">بيانات العميل</h4>
                                                            <h5 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">إسم العميل : <span>{{$order->name}}</span> </h5> 
                                                            <h5 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">رقم الجوال : <span>{{$order->phone}}</span> </h5> 
                                                            <h5 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">العنوان    : <span>{{$order->address}} - رقم بناية {{$order->buildingNo}} رقم طابق {{$order->floorNo}} رقم شقة {{$order->flatNo}}</span> </h5> 
                                                    </div>
                                                    
                                                    <div style="float: left;" class="col-md-6">
                                                        @if($deliverinfo)
                                                            <h4 style="text-align:end">بيانات المندوب</h4>
                                                            <h5 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">إسم العميل : <span>{{$deliverinfo->name}}</span> </h5> 
                                                            <h5 style="text-align: right;" class=" lh-3 mg-b-20" class="font-weight-bold">رقم الجوال : <span>{{$deliverinfo->phone}}</span> </h5> 
                                                        @endif
                                                    </div>
                                                </div>

                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">إلغاء</button>
                                                </div>

                                            </div>
                                        </div>
                                        </div>
                                            <?php 
                                                $pricetotal       += $order->price;
                                                $delivercosttotal += $order->delivercost;
                                            ?>
                                        @endforeach

                                            <h5 style="text-align:right;">إجمالى تكلفة الطلبات : <span style="color:#17B794;">{{$pricetotal}} ريال</span> </h5>
                                            <h5 style="text-align:right;">إجمالى تكلفة التوصيل : <span style="color:#17B794;" > {{$delivercosttotal}} ريال </span> </h5>
                                    </tbody>
                                </table>
                                
                            </div>
                            @else 
                                <p class="text-center">لا يوجد طلبات منتهية حاليا  </p>
                            @endif
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

@endsection