@extends('admin/include/master')
@section('title') لوحة التحكم | إضافة مندوب جديد @endsection
@section('content')


  <div class="my-3 my-md-5">
    <div class="container">
      
      <div class="row">
        <div class="col-12">
          {!! Form::open(array('method' => 'post','files' => true,'class' => 'card','url' =>'adminpanel/users')) !!}
            
            <div dir="rtl"  class="card-header">
              <h3 class="card-title">إضافة مندوب جديد</h3>
            </div>

            <div class="card-body">
              <div class="row">
                <div class="col-md-12 col-lg-12">

                <div style="padding: 2%;" class="card">
                    <label class="form-label text-center">المعلومات الشخصية</label>

                    <div class="form-group">
                          <label class="form-label">الإسم بالكامل</label>
                          <input type="text" class="form-control" name="name" value="{{ old('name') }}" placeholder="ادخل الإسم بالكامل" required>
                          @if ($errors->has('name'))
                          <div style="color: crimson;font-size: 18px;" class="error">{{ $errors->first('name') }}</div>
                          @endif
                    </div>

                    <div class="form-group">
                        <label class="form-label">رقم الهوية</label>
                        <input type="text" class="form-control" name="idNo" value="{{ old('idNo') }}" placeholder="ادخل رقم الهوية" required>
                        @if ($errors->has('idNo'))
                        <div style="color: crimson;font-size: 18px;" class="error">{{ $errors->first('idNo') }}</div>
                        @endif
                    </div>

                    <div class="form-group">
                        <label class="form-label">الجنسية</label>
                        <input type="text" class="form-control" name="nationality" value="{{ old('nationality') }}" placeholder="ادخل الجنسية" required>
                        @if ($errors->has('nationality'))
                        <div style="color: crimson;font-size: 18px;" class="error">{{ $errors->first('nationality') }}</div>
                        @endif
                    </div>

                    <div class="form-group">
                        <label class="form-label">المدينة</label>
                        <input type="text" class="form-control" name="city" value="{{ old('city') }}" placeholder="ادخل المدينة" required>
                        @if ($errors->has('city'))
                        <div style="color: crimson;font-size: 18px;" class="error">{{ $errors->first('city') }}</div>
                        @endif
                    </div>

                    <div class="form-group">
                        <label class="form-label">رقم الجوال</label>
                        <input type="text" class="form-control" name="phone" value="{{ old('phone') }}" placeholder="ادخل رقم الجوال" required>
                        @if ($errors->has('phone'))
                        <div style="color: crimson;font-size: 18px;" class="error">{{ $errors->first('phone') }}</div>
                        @endif
                    </div>

                    <div class="form-group">
                        <label class="form-label">كلمة المرور</label>
                        <input type="password" class="form-control" name="password" placeholder="كلمة المرور" required>
                        @if ($errors->has('password'))
                        <div style="color: crimson;font-size: 18px;" class="error">{{ $errors->first('password') }}</div>
                        @endif
                    </div>

                    <div class="form-group">
                        <label class="form-label"> اعادة كلمة المرور</label>
                        <input type="password" class="form-control" name="confirmpassword" placeholder=" اعادة كلمة المرور" required>
                        @if ($errors->has('confirmpassword'))
                        <div style="color: crimson;font-size: 18px;" class="error">{{ $errors->first('confirmpassword') }}</div>
                        @endif
                    </div>

                    <div class="form-group">
                        <label class="form-label">البريد الإلكترونى [إختيارى]</label>
                        <input type="text" class="form-control" name="email" value="{{ old('email') }}" placeholder="ادخل البريد الإلكترونى">
                        @if ($errors->has('email'))
                        <div style="color: crimson;font-size: 18px;" class="error">{{ $errors->first('email') }}</div>
                        @endif
                    </div>
                </div>
                
                 <div style="padding: 2%;" class="card">
                    <label class="form-label text-center">بيانات المركبة [إختيارى]</label>

                    <div class="form-group">
                        <label class="form-label">نوع المركبة</label>
                        <input type="text" class="form-control" name="vehicletype" value="{{ old('vehicletype') }}" placeholder="ادخل نوع المركبة">
                        @if ($errors->has('vehicletype'))
                        <div style="color: crimson;font-size: 18px;" class="error">{{ $errors->first('vehicletype') }}</div>
                        @endif
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">الموديل</label>
                        <input type="text" class="form-control" name="vehiclemodel" value="{{ old('vehiclemodel') }}" placeholder="ادخل الموديل" >
                        @if ($errors->has('vehiclemodel'))
                        <div style="color: crimson;font-size: 18px;" class="error">{{ $errors->first('vehiclemodel') }}</div>
                        @endif
                    </div>

                    <div class="form-group">
                        <label class="form-label">سنة الصنع</label>
                        <input type="text" class="form-control" name="vehicleyear" value="{{ old('vehicleyear') }}" placeholder="ادخل سنة الصنع">
                        @if ($errors->has('vehicleyear'))
                        <div style="color: crimson;font-size: 18px;" class="error">{{ $errors->first('vehicleyear') }}</div>
                        @endif
                    </div>

                    <div class="form-group">
                        <label class="form-label">رقم اللوحة</label>
                        <input type="text" class="form-control" name="plateNo" value="{{ old('plateNo') }}" placeholder="ادخل رقم اللوحة" >
                        @if ($errors->has('plateNo'))
                        <div style="color: crimson;font-size: 18px;" class="error">{{ $errors->first('plateNo') }}</div>
                        @endif
                    </div>

                    <div class="form-group">
                        <label class="form-label">صورة رخصة القيادة</label>
                        <input style="width:100%;" type="file" class="form-control" name="vehiclelicense">
                        @if ($errors->has('vehiclelicense'))
                        <div style="color: crimson;font-size: 18px;" class="error">{{ $errors->first('vehiclelicense') }}</div>
                        @endif
                    </div>

                    <div class="form-group">
                        <label class="form-label">صورة المركبة</label>
                        <input style="width:100%;" type="file" class="form-control" name="vehicleimage">
                        @if ($errors->has('vehicleimage'))
                        <div style="color: crimson;font-size: 18px;" class="error">{{ $errors->first('vehicleimage') }}</div>
                        @endif
                    </div>

                </div>

                  <div class="btn-list text-center">
                      <button type="submit" class="btn btn-primary col-md-4">إضافة</button>
                  </div>

                </div>
              </div>
            </div>

          {!! Form::close() !!}
      </div>
    </div>
  </div>


@endsection 
