<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\API\BaseController as BaseController;
use Illuminate\Http\Request;
use App\Events\orderevent;
use Validator;
use DB;
use App\setting;
use App\slider;
use App\order;
use App\member;
use App\notification;
use App\rate;

class orderController  extends BaseController
{    
    public function makeorder(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'buyer_id'    => 'required',
            'lat'         => 'required',
            'lng'         => 'required',
            'address'     => 'required',
            'payment'     => 'required',
        ]);

        if($validator->fails())
        {
            return $this->sendError('error',$validator->errors());
        }

        $latitude       =  $request->lat;
        $longitude      =  $request->lng;
        $alldelivers    =   DB::table("members")->where('role',1)->where('activate',1)->where('busy',0)->select("*", DB::raw("6371 * acos(cos(radians(" . $latitude . "))
                            * cos(radians(lat)) * cos(radians(lng) - radians(" . $longitude . "))
                            + sin(radians(" .$latitude. ")) * sin(radians(lat))) AS distance"));
        $alldelivers    =   $alldelivers->having('distance', '<', 200)->orderBy('distance', 'asc')->get();
        

        if(count($alldelivers) == 0)
        {
            $respo    = 'لا يوجد مندوبين متاحيين حاليا الرجاء الإنتظار قليلا وأعد المحاولة ';
            return $this->sendError('error',(object) $respo);
        }
        else 
        {
            $data     = $request->all();
            $neworder = order::create($data);

            foreach($alldelivers as $deliver)
            {
                $newnotification = new notification;
                $newnotification->order_id = $neworder->id;
                $newnotification->user_id  = $deliver->id;
                $newnotification->buyer_id = $request->buyer_id;
                $newnotification->save();

                // $optionBuilder = new OptionsBuilder();
                // $optionBuilder->setTimeToLive(60*20);
            
                // $notificationBuilder = new PayloadNotificationBuilder('تطبيق يمامة');
                // $notificationBuilder->setBody(طلب جديد )
                //                     ->setSound('default');
            
                // $dataBuilder = new PayloadDataBuilder();
                // $dataBuilder->addData(['a_type' => 'message']);
                // $option       = $optionBuilder->build();
                // $notification = $notificationBuilder->build();
                // $data         = $dataBuilder->build();
                // $token        = $deliver->firebase_token ;
            
                // $downstreamResponse = FCM::sendTo($token, $option, $notification, $data);
            
                // $downstreamResponse->numberSuccess();
                // $downstreamResponse->numberFailure();
                // $downstreamResponse->numberModification();            
                // $downstreamResponse->tokensToDelete();
                // $downstreamResponse->tokensToModify();
                // $downstreamResponse->tokensToRetry();

            }
        }
        
        $neworderscount     = DB::table('orders')->where('status',0)->count();
        $revieworderscount  = DB::table('orders')->where('status',1)->count();
        $acceptorderscount  = DB::table('orders')->where('status',2)->count();
        $cancelorderscount  = DB::table('orders')->where('status',3)->count();
        $finishedorderscount= DB::table('orders')->where('status',4)->count();
        event(new orderevent($neworderscount,$revieworderscount,$acceptorderscount,$cancelorderscount,$finishedorderscount));
        $respo    = 'برجاء الإنتظار جارى استقبال طلبك الأن';
        return $this->sendResponse('success',(object) $respo);
    }
    
    public function deliverycount(Request $request)
    {
        $latitude       =  $request->lat;
        $longitude      =  $request->lng;
        $alldelivers    =   DB::table("members")->where('role',1)->where('activate',1)->where('busy',0)->select("*", DB::raw("6371 * acos(cos(radians(" . $latitude . "))
                            * cos(radians(lat)) * cos(radians(lng) - radians(" . $longitude . "))
                            + sin(radians(" .$latitude. ")) * sin(radians(lat))) AS distance"));
        $alldelivers    =   $alldelivers->having('distance', '<', 122)->orderBy('distance', 'asc')->get();
                
        $respo = count($alldelivers);
        if($respo == 0)
        {
            return $this->sendError('error',(object) $respo);
        }
        else 
        {
            return $this->sendResponse('success',(object) $respo);
        }
        
    }
    
    // الطلب الحالى للمندوب
    public function deliverorders(Request $request)
    {
        $deliverorders = notification::where('user_id',$request->user_id)->where('status',0)->get();
        $currentorders = array();
        if(count($deliverorders) == 0)
        {
            $response = [
            'message' => false,
            'scalar'  => 'لا يوجد طلبات حالية',
            'data'    => $currentorders,
            ];
            return response()->json($response,200);
           // return $this->sendError('error',(object) $respo);
        }
        else 
        {
            foreach($deliverorders as $order)
            {
                $orderinfo = order::where('id',$order->order_id)->first();
                $buyerinfo = $orderinfo ? member::where('id',$orderinfo->buyer_id)->first() : 0 ;
                array_push($currentorders,[
                    'id'           => $order->id,   
                    'buyer_id'     => $buyerinfo->id,  
                    'buyer_name'   => $buyerinfo->name, 
                    'buyer_image'  => asset('users/images/defaultuser.png'),  
                    'order'        => $orderinfo ? $orderinfo->order : '',  
                    'lat'          => $orderinfo ? $orderinfo->lat : '',  
                    'lng'          => $orderinfo ? $orderinfo->lng : '',  
                    'address'      => $orderinfo ? $orderinfo->address : '',  
                    'payment'      => $orderinfo ? $orderinfo->payment : '',  
                    'status'       => $orderinfo ? $orderinfo->status : '',  
                    'created_at'   => $orderinfo ? $orderinfo->created_at : '',  
                ]);
            }
            
            $response = [
            'message' => true,
            'scalar'  => '',
            'data'    => $currentorders,
            ];
            return response()->json($response,200);
            //return $this->sendResponse('success', $currentorders);
        }
    }
    
    // تقديم عرض سعر بواسطة المندوب
    public function applyoffer(Request $request)
    {
        $offerinfo = notification::where('id',$request->offer_id)->where('user_id',$request->user_id)->where('status',0)->first();
        if($offerinfo)
        {
            $offerinfo->price         = $request->price;
            $offerinfo->delivercost   = $request->delivercost;
            $offerinfo->expectedtime  = $request->expectedtime;
            $offerinfo->status        = 1;
            $offerinfo->save();
            DB::table('orders')->where('id',$offerinfo->order_id)->update(['status' => 1]);
            $buyerinfo = member::where('id',$request->buyer_id)->first();
            if($buyerinfo)
            {
                if($buyerinfo->firebase_token != null && $buyerinfo->firebase_token != 0)
                {
                    // $optionBuilder = new OptionsBuilder();
                    // $optionBuilder->setTimeToLive(60*20);
                
                    // $notificationBuilder = new PayloadNotificationBuilder('تطبيق يمامة');
                    // $notificationBuilder->setBody('عرض سعر جديد ')
                    //                     ->setSound('default');
                
                    // $dataBuilder = new PayloadDataBuilder();
                    // $dataBuilder->addData(['a_type' => 'message']);
                    // $option       = $optionBuilder->build();
                    // $notification = $notificationBuilder->build();
                    // $data         = $dataBuilder->build();
                    // $token        = $buyerinfo->firebase_token ;
                
                    // $downstreamResponse = FCM::sendTo($token, $option, $notification, $data);
                
                    // $downstreamResponse->numberSuccess();
                    // $downstreamResponse->numberFailure();
                    // $downstreamResponse->numberModification();            
                    // $downstreamResponse->tokensToDelete();
                    // $downstreamResponse->tokensToModify();
                    // $downstreamResponse->tokensToRetry();
                }
            }
            $neworderscount     = DB::table('orders')->where('status',0)->count();
            $revieworderscount  = DB::table('orders')->where('status',1)->count();
            $acceptorderscount  = DB::table('orders')->where('status',2)->count();
            $cancelorderscount  = DB::table('orders')->where('status',3)->count();
            $finishedorderscount= DB::table('orders')->where('status',4)->count();
            event(new orderevent($neworderscount,$revieworderscount,$acceptorderscount,$cancelorderscount,$finishedorderscount));
            $respo = 'تم إرسال عرض السعر بنجاح';
            return $this->sendResponse('success',(object) $respo); 
        }
        else 
        {
            $respo = 'الطلب غير متاح';
            return $this->sendError('error',(object) $respo); 
        }
    }
    
    //الطلبات الحالية والمنتهية للمندوب
    public function mydeliverorders(Request $request)
    {
        $myorders      = $request->status == 2 ? order::where('user_id',$request->user_id)->where('status',2)->get() : order::where('user_id',$request->user_id)->where('status','!=',2)->get();
        $currentorders = array();
        
        if(count($myorders) == 0)
        {
            $response = [
                'message' => false,
                'scalar'  => 'لا يوجد طلبات ',
                'data'    => $currentorders,
            ];
            return response()->json($response,200);
        }
        else 
        {
            foreach($myorders as $order)
            {
                $buyerinfo   = member::where('id',$order->buyer_id)->first();
                $deliverinfo = member::where('id',$request->user_id)->first();
                
                array_push($currentorders,[
                    'id'            => $order->id,    
                    'user_id'       => $order->user_id,  
                    'buyer_id'      => $buyerinfo->id,
                    'buyer_name'    => $buyerinfo->name,  
                    'buyer_phone'   => $buyerinfo->phone,  
                    'deliver_lat'   => $deliverinfo->lat,  
                    'deliver_lng'   => $deliverinfo->lng,  
                    'order'         => $order->order,  
                    'price'         => $order->price,
                    'delivercost'   => $order->delivercost,
                    'expectedtime'  => $order->expectedtime,
                    'lat'           => $order->lat,  
                    'lng'           => $order->lng,  
                    'address'       => $order->address,  
                    'payment'       => $order->payment,  
                    'status'        => $order->status,  
                    'created_at'    => $order->created_at,  
                ]);
            }
            
            $response = [
                'message' => true,
                'scalar'  => '',
                'data'    => $currentorders,
            ];
            
            return response()->json($response,200);
        }
    }
    
    // الطلب الحالى للعميل
    public function myorderoffers(Request $request)
    {
        $myorderoffers = notification::where('buyer_id',$request->buyer_id)->where('status',1)->get();
        $currentorders = array();
        if(count($myorderoffers) == 0)
        {
            $response = [
                'message' => false,
                'scalar'  => 'لا يوجد عروض حالية ',
                'data'    => $currentorders,
            ];
            return response()->json($response,200);
        }
        else 
        {
            
            foreach($myorderoffers as $offer)
            {
                $orderinfo     = order::where('id',$offer->order_id)->first();
                $deliverinfo   = member::where('id',$offer->user_id)->first();
                $deliverrates  = rate::where('user_id',$offer->user_id)->get();
                $sumrates      = 0;
                foreach($deliverrates as $value)
                {
                    $sumrates+= $value->rate;
                }
                $fullrate = $sumrates != 0 ? $sumrates/count($deliverrates) : 0;  
                array_push($currentorders,[
                    'id'           => $offer->id,   
                    'user_id'      => $deliverinfo->id,  
                    'deliver_image'=> asset('users/images/defaultdeliverman.png'),
                    'deliver_name' => $deliverinfo->name,  
                    'deliver_rate' => $fullrate, 
                    'order'        => $orderinfo ? $orderinfo->order : '',  
                    'price'        => $offer->price,
                    'delivercost'  => $offer->delivercost,
                    'expectedtime' => $offer->expectedtime,
                    'lat'          => $orderinfo ? $orderinfo->lat : '',  
                    'lng'          => $orderinfo ? $orderinfo->lng : '',  
                    'address'      => $orderinfo ? $orderinfo->address : '',  
                    'payment'      => $orderinfo ? $orderinfo->payment : '',  
                    'status'       => $orderinfo ? $orderinfo->status : '',  
                    'created_at'   => $orderinfo ? $orderinfo->created_at : '',  
                ]);
            }
             $response = [
                'message' => true,
                'scalar'  => '',
                'data'    => $currentorders,
            ];
            return response()->json($response,200);
        }
    }
    
    // تنفيذ الطلب بواسطة العميل
    public function confirmoffer(Request $request)
    {
        $offerinfo = notification::where('id',$request->offer_id)->where('status',1)->first();
        if($offerinfo)
        {
            $deliverinfo = member::where('id',$offerinfo->user_id)->where('busy',0)->first();
            if($deliverinfo)
            {
                $orderinfo = order::where('id',$offerinfo->order_id)->where('status',1)->first();
                if($orderinfo)
                {
                    DB::table('orders')->where('id',$orderinfo->id)->update(['user_id' => $deliverinfo->id,'price' => $offerinfo->price,'delivercost' => $offerinfo->delivercost,'expectedtime' => $offerinfo->expectedtime,'status' => 2]);
                    DB::table('members')->where('id',$deliverinfo->id)->update(['busy' => 1]);
                    DB::table('notifications')->where('id',$offerinfo->id)->update(['status' => 2]);
                    if($deliverinfo->firebase_token != null && $deliverinfo->firebase_token != 0)
                    {
                        // $optionBuilder = new OptionsBuilder();
                        // $optionBuilder->setTimeToLive(60*20);
                    
                        // $notificationBuilder = new PayloadNotificationBuilder('تطبيق يمامة');
                        // $notificationBuilder->setBody('قبول عرض سعرك ')
                        //                     ->setSound('default');
                    
                        // $dataBuilder = new PayloadDataBuilder();
                        // $dataBuilder->addData(['a_type' => 'message']);
                        // $option       = $optionBuilder->build();
                        // $notification = $notificationBuilder->build();
                        // $data         = $dataBuilder->build();
                        // $token        = $deliverinfo->firebase_token ;
                    
                        // $downstreamResponse = FCM::sendTo($token, $option, $notification, $data);
                    
                        // $downstreamResponse->numberSuccess();
                        // $downstreamResponse->numberFailure();
                        // $downstreamResponse->numberModification();            
                        // $downstreamResponse->tokensToDelete();
                        // $downstreamResponse->tokensToModify();
                        // $downstreamResponse->tokensToRetry();
                    }

                    $neworderscount     = DB::table('orders')->where('status',0)->count();
                    $revieworderscount  = DB::table('orders')->where('status',1)->count();
                    $acceptorderscount  = DB::table('orders')->where('status',2)->count();
                    $cancelorderscount  = DB::table('orders')->where('status',3)->count();
                    $finishedorderscount= DB::table('orders')->where('status',4)->count();
                    event(new orderevent($neworderscount,$revieworderscount,$acceptorderscount,$cancelorderscount,$finishedorderscount));
                    $respo = 'تم تأكيد الطلب بنجاح وجارى التنفيذ';
                    return $this->sendResponse('success',(object) $respo);
                }
                else 
                {
                   $respo = 'الطلب غير متاح حاليا';
                   return $this->sendError('error',(object) $respo); 
                }
            }
            else 
            {
                $respo = 'المندوب لم يعد متاح حاليا الرجاء تأكيد عرض أخر';
                return $this->sendError('error',(object) $respo);
            }            
        }
        else 
        {
            $respo = 'العرض غير متاح';
            return $this->sendError('error',(object) $respo);
        }

    }

    // إستلام الطلب بواسطة العميل
    public function receiveorder(Request $request)
    {
       $orderinfo = order::where('id',$request->order_id)->where('buyer_id',$request->buyer_id)->where('status',2)->first();
        if($orderinfo)
        {
            DB::table('orders')->where('id',$orderinfo->id)->update(['status' => 4]);
            DB::table('members')->where('id',$orderinfo->user_id)->update(['busy' => 0]);
            
            $neworderscount     = DB::table('orders')->where('status',0)->count();
            $revieworderscount  = DB::table('orders')->where('status',1)->count();
            $acceptorderscount  = DB::table('orders')->where('status',2)->count();
            $cancelorderscount  = DB::table('orders')->where('status',3)->count();
            $finishedorderscount= DB::table('orders')->where('status',4)->count();
            event(new orderevent($neworderscount,$revieworderscount,$acceptorderscount,$cancelorderscount,$finishedorderscount));
            $respo = 'تم إستلام الطلب بنجاح';
            return $this->sendResponse('success',(object) $respo);
        }
        else 
        {
            $respo = 'الطلب غير متاح حاليا';
            return $this->sendError('error',(object) $respo); 
        }
    }

    // إلغاء الطلب بواسطة المندوب أو العميل
    public function cancelorder(Request $request)
    {
       $orderinfo = order::where('id',$request->order_id)->first();
        if($orderinfo)
        {
            DB::table('orders')->where('id',$orderinfo->id)->update(['status' => 3]);
            DB::table('members')->where('id',$orderinfo->user_id)->update(['busy' => 0]);
            
            $neworderscount     = DB::table('orders')->where('status',0)->count();
            $revieworderscount  = DB::table('orders')->where('status',1)->count();
            $acceptorderscount  = DB::table('orders')->where('status',2)->count();
            $cancelorderscount  = DB::table('orders')->where('status',3)->count();
            $finishedorderscount= DB::table('orders')->where('status',4)->count();
            event(new orderevent($neworderscount,$revieworderscount,$acceptorderscount,$cancelorderscount,$finishedorderscount));
            $respo = 'تم إلغاء الطلب بنجاح';
            return $this->sendResponse('success',(object) $respo);
        }
        else 
        {
            $respo = 'الطلب غير متاح حاليا';
            return $this->sendError('error',(object) $respo); 
        }
    }
    
    // 
    public function deleteorder(Request $request)
    {
       $orderinfo = order::where('id',$request->order_id)->first();
        if($orderinfo)
        {
            notification::where('order_id',$orderinfo->id)->delete();
            $orderinfo->delete();
            
            $neworderscount     = DB::table('orders')->where('status',0)->count();
            $revieworderscount  = DB::table('orders')->where('status',1)->count();
            $acceptorderscount  = DB::table('orders')->where('status',2)->count();
            $cancelorderscount  = DB::table('orders')->where('status',3)->count();
            $finishedorderscount= DB::table('orders')->where('status',4)->count();
            event(new orderevent($neworderscount,$revieworderscount,$acceptorderscount,$cancelorderscount,$finishedorderscount));
            $respo = 'تم حذف الطلب بنجاح';
            return $this->sendResponse('success',(object) $respo);
        }
        else 
        {
            $respo = 'الطلب غير متاح حاليا';
            return $this->sendError('error',(object) $respo); 
        }
    }

    //الطلبات الحالية والمنتهية للعميل
    public function myorders(Request $request)
    {
        $myorders = $request->status == 2 ? order::where('buyer_id',$request->buyer_id)->where('status',2)->where('user_id','!=',0)->get() : order::where('buyer_id',$request->buyer_id)->where('user_id','!=',0)->whereIn('status', [3,4])->get();
        $currentorders = array();
        if(count($myorders) == 0)
        {
            $response = [
                'message' => false,
                'scalar'  => 'لا يوجد طلبات ',
                'data'    => $currentorders,
            ];
            return response()->json($response,200);
        }
        else 
        {
            
            foreach($myorders as $order)
            {
                $deliverinfo   = member::where('id',$order->user_id)->first();
                $deliverrates  = rate::where('user_id',$order->user_id)->get();
                $sumrates      = 0;
                foreach($deliverrates as $value)
                {
                    $sumrates+= $value->rate;
                }
                $fullrate = $sumrates != 0 ? $sumrates/count($deliverrates) : 0;  
                array_push($currentorders,[
                    'id'            => $order->id,
                    'buyer_id'      => $order->buyer_id,    
                    'user_id'       => $deliverinfo->id,  
                    'deliver_name'  => $deliverinfo->name,  
                    'deliver_phone' => $deliverinfo->phone,  
                    'deliver_lat'   => $deliverinfo->lat,  
                    'deliver_lng'   => $deliverinfo->lng,  
                    'deliver_rate'  => $fullrate, 
                    'order'         => $order->order,  
                    'price'         => $order->price,
                    'delivercost'   => $order->delivercost,
                    'expectedtime'  => $order->expectedtime,
                    'lat'           => $order->lat,  
                    'lng'           => $order->lng,  
                    'address'       => $order->address,  
                    'payment'       => $order->payment,  
                    'status'        => $order->status,  
                    'created_at'    => $order->created_at,  
                ]);
            }
            $response = [
                'message' => true,
                'scalar'  => '',
                'data'    => $currentorders,
            ];
            return response()->json($response,200);
        }
    }
    
    public function singelorder(Request $request)
    {
        $order =  order::where('id',$request->order_id)->first();
        $currentorders = array();
        if($order)
        {
            $deliverinfo   = member::where('id',$order->user_id)->first();
            $deliverrates  = rate::where('user_id',$order->user_id)->get();
            $sumrates      = 0;
            foreach($deliverrates as $value)
            {
                $sumrates+= $value->rate;
            }
            $fullrate = $sumrates != 0 ? $sumrates/count($deliverrates) : 0;  
            array_push($currentorders,[
                'id'            => $order->id,
                'buyer_id'      => $order->buyer_id,    
                'user_id'       => $deliverinfo->id,  
                'deliver_name'  => $deliverinfo->name,  
                'deliver_phone' => $deliverinfo->phone,  
                'deliver_lat'   => $deliverinfo->lat,  
                'deliver_lng'   => $deliverinfo->lng,  
                'deliver_rate'  => $fullrate, 
                'order'         => $order->order,  
                'price'         => $order->price,
                'delivercost'   => $order->delivercost,
                'expectedtime'  => $order->expectedtime,
                'lat'           => $order->lat,  
                'lng'           => $order->lng,  
                'address'       => $order->address,  
                'payment'       => $order->payment,  
                'status'        => $order->status,  
                'created_at'    => $order->created_at,  
            ]);
            $response = [
                'message' => true,
                'scalar'  => '',
                'data'    => $currentorders,
            ];
            return response()->json($response,200);
        }
        else 
        {
            $response = [
                'message' => false,
                'scalar'  => 'الطلب غير متاح',
                'data'    => $currentorders,
            ];
            return response()->json($response,200);
        }
    }
    
}
