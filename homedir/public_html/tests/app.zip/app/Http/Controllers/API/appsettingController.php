<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\API\BaseController as BaseController;
use Illuminate\Http\Request;
use App\Events\orderevent;
use Validator;
use DB;
use App\setting;
use App\slider;
use App\order;
use App\member;
use App\rate;



class appsettingController  extends BaseController
{
    public function settingindex(Request $request)
    {   
        $jsonarr                  = array();
        $settinginfo              = setting::first();
        $jsonarr['logo']          = asset('users/images/'.$settinginfo->logo);
        $jsonarr['splach']        = asset('users/images/'.$settinginfo->splach);
        $jsonarr['splachvideo']   = asset('users/images/'.$settinginfo->splachvideo);
        $jsonarr['image']         = asset('users/images/'.$settinginfo->image);
        $jsonarr['mindeliverycost']         = $settinginfo->mindeliverycost;
        $jsonarr['maxdeliverycost']         = $settinginfo->maxdeliverycost;
        return $this->sendResponse('success',$jsonarr);
    }

    public function addrate(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'buyer_id'     => 'required',
            'user_id'      => 'required',
            'rate'         => 'required',
            'servicerate'  => 'required',
        ],
        [
          'buyer_id.required'      =>  'هذا الحقل مطلوب',
          'user_id.required'       =>  'هذا الحقل مطلوب',
          'rate.required'          =>  'هذا الحقل مطلوب',
          'servicerate.required'   =>  'هذا الحقل مطلوب',
        ]);

        if($validator->fails())
        {
            return $this->sendError('error',$validator->errors());
        }

        $rated = rate::where('buyer_id',$request->buyer_id)->where('user_id',$request->user_id)->first();
        if($rated)
        {
            $respo = 'تم التقييم سابقا';
            return $this->sendError('error', (object) $respo);
        }

        $newrate              = new rate;
        $newrate->buyer_id    = $request->buyer_id;
        $newrate->user_id     = $request->user_id;
        $newrate->rate        = $request->rate;
        $newrate->servicerate = $request->servicerate;
        $newrate->save();
        $respo = 'تم التقييم بنجاح';
        return $this->sendResponse('success', (object) $respo);
    }
    
    public function privacy(Request $request)
    {
        $privacy = setting::value('privacy');
        return $this->sendResponse('success',$privacy);
    }
    
    public function policy(Request $request)
    {
        $policy = setting::value('policy');
        return $this->sendResponse('success',$policy);
    }

}
