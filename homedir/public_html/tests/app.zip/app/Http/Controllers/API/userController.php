<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\API\BaseController as BaseController;
use App\Mail\activationmail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Hash;
use App\member;
use App\order;
use App\rate;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Validator;
use Illuminate\Http\Request;
use DB;

class userController extends BaseController
{
    //registeration process 
    public function register(Request $request)
    {
      if($request->social_type == 'facebook' || $request->social_type == 'google')
      {
          $usersocial = member::where('social_id',$request->social_id)->first();
          if($usersocial)
          {
            $usersocial['image']       = $usersocial->role == 0 ?  asset('users/images/defaultuser.png') : asset('users/images/defaultdeliverman.png');
            $usersocial['countorders'] = $usersocial->role == 0 ? order::where('buyer_id',$usersocial->id)->count() : order::where('user_id',$usersocial->id)->count() ;
            $usersocial['countrates']  = $usersocial->role == 0 ? rate::where('buyer_id',$usersocial->id)->count()  : rate::where('user_id',$usersocial->id)->count() ;
            return $this->sendResponse('success', $usersocial); 
          }
          else 
          {
              $validator = Validator::make($request->all(), [
                'social_type'    => 'required',
                'social_id'      => 'required',
                'name'           => 'required',
                'email'          => 'required|email|unique:members',
                'firebase_token' => 'required',
              ],
              [
                  'social_type.required'      =>  'هذا الحقل مطلوب',
                  'social_id.required'        =>  'هذا الحقل مطلوب',
                  'name.required'             =>  'هذا الحقل مطلوب',
                  'email.required'            =>  'هذا الحقل مطلوب',
                  'email.email'               =>  'صيغة البريد الإلكترونى خاطئة',
                  'email.unique'              =>  'تم اخذ رقم البريد الإلكترونى سابقا',
                  'firebase_token.required'   =>   'هذا الحقل مطلوب',
              ]);
      
              if($validator->fails())
              {
                return $this->sendError('error',$validator->errors());     
              }
              
              $user                 = new member;
              $user->name           = $request->name;
              $user->email          = $request->email;
              $user->phone          = $request->phone;
              $user->social_id      = $request->social_id;
              $user->social_type    = $request->social_type ;
              $user->firebase_token = $request->firebase_token;
              $user->activate       = 1 ;
              $user->save();
              $userinfo = member::where('id',$user->id)->first(); 
              $userinfo['image']       = $userinfo->role == 0 ?  asset('users/images/defaultuser.png') : asset('users/images/defaultdeliverman.png');
              $userinfo['countorders'] = $userinfo->role == 0 ? order::where('buyer_id',$userinfo->id)->count() : order::where('user_id',$userinfo->id)->count() ;
              $userinfo['countrates']  = $userinfo->role == 0 ? rate::where('buyer_id',$userinfo->id)->count()  : rate::where('user_id',$userinfo->id)->count() ;
              return $this->sendResponse('success', $userinfo); 
          }
      }
      else
      {
          $userphone = member::where('phone',$request->phone)->first();
          if($userphone)
          {
                $validator = Validator::make($request->all(), [
                    'firebase_token' => 'required',
                ],
                [
                    'firebase_token.required'  =>  'هذا الحقل مطلوب',
                ]);
                
                if($validator->fails())
                {
                    return $this->sendError('error',$validator->errors());
                }

                $randomregcode              = substr(str_shuffle("0123456789"), 0, 6);
                $userphone->registercode    = $randomregcode; 
                $userphone->activate        = 0;
                $userphone->firebase_token  = $request->firebase_token;
                $userphone->save();
                $userphone['image']       = $userphone->role == 0 ?  asset('users/images/defaultuser.png') : asset('users/images/defaultdeliverman.png');
                $userphone['countorders'] = $userphone->role == 0 ? order::where('buyer_id',$userphone->id)->count() : order::where('user_id',$userphone->id)->count() ;
                $userphone['countrates']  = $userphone->role == 0 ? rate::where('buyer_id',$userphone->id)->count()  : rate::where('user_id',$userphone->id)->count() ;
                
                //set POST variables
                $url = 'https://www.hisms.ws/api.php/send_sms';
                $fields_string = '';
                $fields = array(
                	'username' => urlencode('0570070098'),
                	'password' => urlencode('Amfm1988'),
                	'numbers' => urlencode($request->phone),
                	'sender' => urlencode('yamama'),
                	'message' => urlencode($randomregcode),
                	'send_sms' => urlencode(''),
                );
                
                //url-ify the data for the POST
                foreach($fields as $key=>$value) { $fields_string .= $key.'='.$value.'&'; }
                rtrim($fields_string, '&');
                
                //open connection
                $ch = curl_init();
                
                //set the url, number of POST vars, POST data
                curl_setopt($ch,CURLOPT_URL, $url);
                curl_setopt($ch,CURLOPT_POST, count($fields));
                curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
                
                //execute post
                $result = curl_exec($ch);
                
                //close connection
                curl_close($ch);
            
                return $this->sendResponse('success', $userphone); 
          }
          else 
          {
                $validator = Validator::make($request->all(), [
                    'name'           => 'required',  
                    'phone'          => 'required|unique:members',  
                    'firebase_token' => 'required',
                ],
                [
                    'name.required'            =>  'هذا الحقل مطلوب',
                    'phone.required'           =>  'هذا الحقل مطلوب',
                    'phone.unique'             =>  'تم اخذ رقم الجوال سابقا',
                    'firebase_token.required'  =>  'هذا الحقل مطلوب',
                ]);
                
                if($validator->fails())
                {
                    return $this->sendError('error',$validator->errors());
                }

                $user                 = new member;
                $user->name           = $request->name;
                $user->phone          = $request->phone;
                $user->social_type    = $request->social_type ;
                $randomregcode        = substr(str_shuffle("0123456789"), 0, 6);
                $user->registercode   = $randomregcode; 
                $user->save();
                $userinfo                = member::where('id',$user->id)->first();
                $userinfo['image']       = $userinfo->role == 0 ?  asset('users/images/defaultuser.png') : asset('users/images/defaultdeliverman.png');
                $userinfo['countorders'] = $userinfo->role == 0 ? order::where('buyer_id',$userinfo->id)->count() : order::where('user_id',$userinfo->id)->count() ;
                $userinfo['countrates']  = $userinfo->role == 0 ? rate::where('buyer_id',$userinfo->id)->count()  : rate::where('user_id',$userinfo->id)->count() ;
                
                //set POST variables
                $url = 'https://www.hisms.ws/api.php/send_sms';
                $fields_string = '';
                $fields = array(
                	'username' => urlencode('0570070098'),
                	'password' => urlencode('Amfm1988'),
                	'numbers' => urlencode($request->phone),
                	'sender' => urlencode('yamama'),
                	'message' => urlencode($randomregcode),
                	'send_sms' => urlencode(''),
                );
                
                //url-ify the data for the POST
                foreach($fields as $key=>$value) { $fields_string .= $key.'='.$value.'&'; }
                rtrim($fields_string, '&');
                
                //open connection
                $ch = curl_init();
                
                //set the url, number of POST vars, POST data
                curl_setopt($ch,CURLOPT_URL, $url);
                curl_setopt($ch,CURLOPT_POST, count($fields));
                curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
                
                //execute post
                $result = curl_exec($ch);
                
                //close connection
                curl_close($ch);
                
                return $this->sendResponse('success', $userinfo); 
           }
      }
    }
    
    // Activate Account 
    public function activat_account(Request $request)
    {
        $userinfo = member::where('id',$request->user_id)->first();
        if($userinfo->registercode == $request->activatcode)
        {
            $userinfo->activate     = 1;
            $userinfo->registercode = null;
            $userinfo->save();
            $userinfo['image']       = $userinfo->role == 0 ?  asset('users/images/defaultuser.png') : asset('users/images/defaultdeliverman.png');
            $userinfo['countorders'] = $userinfo->role == 0 ? order::where('buyer_id',$userinfo->id)->count() : order::where('user_id',$userinfo->id)->count() ;
            $userinfo['countrates']  = $userinfo->role == 0 ? rate::where('buyer_id',$userinfo->id)->count()  : rate::where('user_id',$userinfo->id)->count() ;
            return $this->sendResponse('success', $userinfo);
        }
        else
        {
            $respo = 'كود التفعيل غير صحيح';
            return $this->sendError('success', (object) $respo);
        }
    }
    
    //register as deliverman process 
    public function registerasdeliverman(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name'             => 'required',
            'idNo'             => 'required|unique:members',
            'city'             => 'required',
            'nationality'      => 'required',
            'phone'            => 'required|unique:members',
            'firebase_token'   => 'required',
        ],
        [
            'name.required'            =>  'هذا الحقل مطلوب',
            'idNo.required'            =>  'هذا الحقل مطلوب',
            'idNo.unique'              =>  'تم اخذ رقم  الهوية سابقا',
            'city.required'            =>  'هذا الحقل مطلوب',
            'nationality.required'     =>  'هذا الحقل مطلوب',
            'phone.required'           =>  'هذا الحقل مطلوب',
            'phone.unique'             =>  'تم اخذ رقم الجوال سابقا',
            'firebase_token.required'  =>  'هذا الحقل مطلوب',
        ]);

        if($validator->fails())
        {
            return $this->sendError('error', $validator->errors());
        }
    
        if($request->email)
        {
            $validator = Validator::make($request->all(), 
            [
                'email'              => 'required|email|unique:members',
            ],
            [
                'email.required'     =>  'هذا الحقل مطلوب',
                'email.unique'       =>  'تم اخذ البريد الالكترونى سابقا',
                'email.email'        =>  'صيغة البريد الإلكترونى خاطئة',
            ]);
        }
        
        if($validator->fails())
        {
            return $this->sendError('error',$validator->errors());
        }

        if($request->hasFile('vehiclelicense'))
        {
            $validator = Validator::make($request->all(), 
            [
                'vehiclelicense'              => 'required|image',
            ],
            [
                'vehiclelicense.required'     =>  'هذا الحقل مطلوب',
                'vehiclelicense.image'        =>  'صيغة الصورة خاطئة',
            ]);
        }
        
        if($validator->fails())
        {
            return $this->sendError('error',$validator->errors());
        }

        if($request->hasFile('vehicleimage'))
        {
            $validator = Validator::make($request->all(), 
            [
                'vehicleimage'              => 'required|image',
            ],
            [
                'vehicleimage.required'     =>  'هذا الحقل مطلوب',
                'vehicleimage.image'        =>  'صيغة الصورة خاطئة',
            ]);
        }
        
        if($validator->fails())
        {
            return $this->sendError('error',$validator->errors());
        }

        $data                 = $request->all();
        $data['social_type']  = 'delivery';
        $data['role']         = 1;
        $data['created_at']   = now();

        if($request->hasFile('vehiclelicense'))
        {
            $image    = $request['vehiclelicense'];
            $filename = 'license'.rand(0,999999).'.'.$image->getClientOriginalExtension();
            $image->move(base_path('users/images/'),$filename);
            $data['vehiclelicense']  = $filename;
        }

        if($request->hasFile('vehicleimage'))
        {
            $image    = $request['vehicleimage'];
            $filename = 'vehicleimage'.rand(0,999999).'.'.$image->getClientOriginalExtension();
            $image->move(base_path('users/images/'),$filename);
            $data['vehicleimage']  = $filename;
        }

        $user   = member::create($data);
        $respo  = 'تم إرسال طلبك بنجاح وسيتم مراجعة طلبك من قبل الإدارة';
        return $this->sendResponse('success', (object) $respo); 
    }

    //Login process
    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'phone'          => 'required',
            'password'       => 'required',
            'firebase_token' => 'required',
        ],
        [
            'phone.required'           =>  'هذا الحقل مطلوب',
            'password.required'        =>  'هذا الحقل مطلوب',
            'firebase_token.required'  =>  'هذا الحقل مطلوب',
        ]);

        if($validator->fails())
        {
            return $this->sendError('success', $validator->errors());
        }

        if(Auth::attempt(['phone' => $request->phone , 'password' => $request->password ,'suspensed' => 0 ])) 
        {
            $userinfo  = Auth::user();
            if(Auth::user()->activate == 1)
            {
                $userinfo->firebase_token = $request->firebase_token;
                $userinfo->save();
                $userinfo['image']       = $userinfo->role == 0 ?  asset('users/images/defaultuser.png') : asset('users/images/defaultdeliverman.png');
                $userinfo['countorders'] = $userinfo->role == 0 ? order::where('buyer_id',$userinfo->id)->count() : order::where('user_id',$userinfo->id)->count() ;
                $userinfo['countrates']  = $userinfo->role == 0 ? rate::where('buyer_id',$userinfo->id)->count()  : rate::where('user_id',$userinfo->id)->count() ;
                return $this->sendResponse('success', $userinfo);  
            }
            elseif(Auth::user()->activate == 0)
            {
                $respo = 'يتعذر الدخول , الحساب غير مفعل الرجاء التواصل مع الإدارة';
                return $this->sendError('success', (object) $respo);
            }
        }
        else
        {
            $respo = 'رقم الجوال او كلمة المرور غير صحيحة';
            return $this->sendError('success', (object) $respo);
        }
    }

    //forgetpassword process
    public function forgetpassword(Request $request)
    {
        $user = member::where('phone',$request->phone)->first();
        if(!$user)
        {
            $respo = 'رقم الجوال غير صحيح';
            return $this->sendError('error', (object) $respo);
        }
        else
        {
            $randomcode       = substr(str_shuffle("0123456789"), 0, 6);
            $user->forgetcode = $randomcode;
            $user->save();
            return $this->sendResponse('success', (object) $user->forgetcode);
        } 
      
    }

    public function activcode(Request $request)
    {
        $userinfo = member::where('phone',$request->phone)->where('forgetcode',$request->forgetcode)->first();
        if($userinfo)
        {
          $userinfo->forgetcode = null;
          $userinfo->save();
          $userinfo['countorders'] = $userinfo->role == 0 ? order::where('buyer_id',$userinfo->id)->count() : order::where('user_id',$userinfo->id)->count() ;
          $userinfo['countrates']  = $userinfo->role == 0 ? rate::where('buyer_id',$userinfo->id)->count()  : rate::where('user_id',$userinfo->id)->count() ;
          return $this->sendResponse('success',$user);
        }
        else 
        {
          $respo = 'كود التفعيل غير صحيح';
          return $this->sendError('error', (object) $respo);
        }
    }

    //rechangepassword process
    public function rechangepass(Request $request)
    {
        $validator = Validator::make($request->all(), 
        [
          'password'    => 'required|min:6',
        ],
        [
            'password.required'        =>  'هذا الحقل مطلوب',
            'password.min'             =>   'كلمة المرور لا تقل عن 6 احرف', 
        ]);
            
        if($validator->fails())
        {
            return $this->sendError('error',$validator->errors());      
        }

        $userinfo   = member::where('phone',$request->phone)->first();
        if($userinfo)
        {
            $userinfo->password  = Hash::make($request['password']);
            $userinfo->save();
            $userinfo['countorders'] = $userinfo->role == 0 ? order::where('buyer_id',$userinfo->id)->count() : order::where('user_id',$userinfo->id)->count() ;
            $userinfo['countrates']  = $userinfo->role == 0 ? rate::where('buyer_id',$userinfo->id)->count()  : rate::where('user_id',$userinfo->id)->count() ;
            return $this->sendResponse('success',$user);
        }
        else 
        {
            $respo = 'رقم الجوال غير صحيح';
            return $this->sendResponse('error', (object) $respo);
        }
    }
    
    //profile process
    public function profile(Request $request)
    {
        $upuser = member::where('id',$request->user_id)->first();
        if($upuser)
        {
            $upuser['countorders'] = $upuser->role == 0 ? order::where('buyer_id',$upuser->id)->count() : order::where('user_id',$upuser->id)->count() ;
            $upuser['countrates']  = $upuser->role == 0 ? rate::where('buyer_id',$upuser->id)->count()  : rate::where('user_id',$upuser->id)->count() ;
            return $this->sendResponse('success', $upuser);
        }
        else
        {    
            $respo = 'هذا المستخدم غير موجود';
            return $this->sendError('success', (object)$respo);
        }
    }
    
    //updating profile process
    public function update(Request $request)
    {
       $upuser = member::where('id',$request->user_id)->first();
        if($upuser)
        {
            $validator = Validator::make($request->all(), [
              'name'          => 'required',
            ],
            [
                'name.required'   =>  'هذا الحقل مطلوب',
            ]);

            if($validator->fails())
            {
                return $this->sendError('error',$validator->errors());
            }

            $data    = $request->all(); 
            if($request['password'])
            {
                $validator = Validator::make($request->all(), [
                  'password'       => 'required|min:6',  
                ],
                [
                    'password.required'        =>  'هذا الحقل مطلوب',
                    'password.min'             =>   'كلمة المرور لا تقل عن 6 احرف', 
                ]);

                if($validator->fails())
                {
                    return $this->sendError('error',$validator->errors());
                }

                $upuser->password  =  Hash::make($request['password']);
            }

            $upuser->update($data); 
            $upuser['countorders'] = $upuser->role == 0 ? order::where('buyer_id',$upuser->id)->count() : order::where('user_id',$upuser->id)->count() ;
            $upuser['countrates']  = $upuser->role == 0 ? rate::where('buyer_id',$upuser->id)->count()  : rate::where('user_id',$upuser->id)->count() ;
            return $this->sendResponse('success', $upuser);
        }
        else
        {    
            $respo = 'هذا المستخدم غير موجود';
            return $this->sendError('success', (object)$respo);
        }
    }

    //update location
    public function updatelocation(Request $request)
    {
        $userinfo = member::where('id',$request->user_id)->first();
        if($userinfo)
        {
            if($request->lat && $request->lng )
            {
                $userinfo->lat = $request->lat;
                $userinfo->lng = $request->lng;
                $userinfo->save();
            }
            
            $userinfo['image']       = $userinfo->role == 0 ?  asset('users/images/defaultuser.png') : asset('users/images/defaultdeliverman.png');
            $userinfo['countorders'] = $userinfo->role == 0 ? order::where('buyer_id',$userinfo->id)->count() : order::where('user_id',$userinfo->id)->count() ;
            $userinfo['countrates']  = $userinfo->role == 0 ? rate::where('buyer_id',$userinfo->id)->count()  : rate::where('user_id',$userinfo->id)->count() ;
            return $this->sendResponse('success', $userinfo);
        }
        else 
        {
            $respo = 'هذا المستخدم غير موجود';
            return $this->sendError('success', (object)$respo);
        }
    }
    
}
