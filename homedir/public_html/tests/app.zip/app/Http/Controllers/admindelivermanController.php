<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;  
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Hash;
use App\Mail\notificationmail;
use App\Mail\contactmail;
use Illuminate\Support\Facades\Mail;
use App\member;  
use App\order;
use Carbon\Carbon;
use DB;  


class admindelivermanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    //members
    public function index()  
    {
        $logo       = DB::table('settings')->value('logo');
        $allusers   = member::orderBy('id','desc')->get();
        return view('admin.users.index',compact('logo','allusers'));
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $logo          = DB::table('settings')->value('logo');
        return view('admin.users.create',compact('logo'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'name'            => 'required',
            'phone'           => 'required|unique:members', 
         ]);

            $data               = $request->all();
            if($request->hasFile('image'))
            {
                $image    = $request['image'];
                $filename = rand(0,9999).'.'.$image->getClientOriginalExtension();
                $image->move(base_path('users/images/'),$filename);
                $data['image'] = $filename;
            }
            else 
            {
                $data['image'] = 'defaultdeliverman.png';
            }
            $newmember          = member::create($data);
            session()->flash('success','تم إضافة مندوب بنجاح');
            return back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $logo              = DB::table('settings')->value('logo');
        $showuser          = member::findorfail($id);
        $revieworders      = order::where('user_id',$id)->where('status',1)->get();
        $acceptorders      = order::where('user_id',$id)->where('status',2)->get();
        $cancelorders      = order::where('user_id',$id)->where('status',3)->get();
        $finishedorders    = order::where('user_id',$id)->where('status',4)->get();
        $pricetotal        = 0;
        $delivercosttotal  = 0;
        return view('admin.users.show',compact('logo','showuser','revieworders','acceptorders','cancelorders','pricetotal','delivercosttotal','finishedorders'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $eduser           = member::find($id);
        $logo             = DB::table('settings')->value('logo');
        return view('admin.users.edit',compact('logo','eduser'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $upmember = member::find($id);

        if(Input::has('suspensed'))
        {
            if($upmember->suspensed == 0)
            {
                DB::table('members')->where('id',$id)->update(['suspensed' => 1]);
                session()->flash('success','تم تعطيل المندوب بنجاح');
                return back();
            }
            else 
            {
                DB::table('members')->where('id',$id)->update(['suspensed' => 0]);
                session()->flash('success','تم تفعيل المندوب بنجاح');
                return back();
            }
        }
        else 
        {
            $this->validate($request,[
                'name'            => 'required',
                'phone'           => 'required|unique:members,phone,'.$id, 
            ]);
    
            $data    = $request->all(); 
            $upmember->update($data);  
            if($request->hasFile('image'))
            {
                $image    = $request['image'];
                $filename = rand(0,9999).'.'.$image->getClientOriginalExtension();
                $image->move(base_path('users/images/'),$filename);
                $upmember->image = $filename;
            }
            $upmember->save();
            session()->flash('success','تم تعديل بيانات المندوب بنجاح');
            return back();
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $deluser = member::find($id);
        if($deluser)
        {
            order::where('user_id',$id)->delete();
            $deluser->delete();
            session()->flash('success','تم حذف المندوب بنجاح');
        }
        return back();  
    }

}
