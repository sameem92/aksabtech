<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\admin;
use App\setting;
use App\member;
use App\order;
use Illuminate\Support\Facades\Auth;

class adminloginController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function index()
    {
        if(Auth::guard('admin')->check()) 
        {
            $logo              = setting::value('logo');
            $phonemembers      = member::where('role',0)->where('social_type','phone')->count();
            $facebookmembers   = member::where('role',0)->where('social_type','facebook')->count();
            $googlemembers     = member::where('role',0)->where('social_type','google')->count();
            $deliveryrequests  = member::where('role',1)->where('activate',0)->count();
            $deliverymembers   = member::where('role',1)->where('activate',1)->count();
            $neworders         = order::where('status',0)->count();
            $revieworders      = order::where('status',1)->count();
            $acceptorders      = order::where('status',2)->count();
            $cancelorders      = order::where('status',3)->count();
            $finishedorders    = order::where('status',4)->count();
            return view('admin.dashboard',compact('logo','phonemembers','facebookmembers','googlemembers','deliveryrequests','deliverymembers','neworders','revieworders','acceptorders','cancelorders','finishedorders'));
        }
        else
        {
            $logo = setting::value('logo');
            return view('admin.login',compact('logo'));
        }
        
    }

    /**
     * Show the form for creating a new resource.
     * 
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $username = $request['username'];
        $pass     = $request['pass'];

        if (Auth::guard('admin')->attempt(['username' => $username, 'password' => $pass])) 
        {
            return redirect('adminpanel');
        }
        else
        {
            session()->flash('loginfailed','اسم المستخدم او كلمة المرور غير صحيحة ! حاول مرة اخرى');
            return back();
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy()
    {
        Auth::guard('admin')->logout();
        return redirect('adminpanel');
    }
}
