<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;  
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Hash;
use App\Mail\notificationmail;
use App\Mail\contactmail;
use Illuminate\Support\Facades\Mail;
use App\member;  
use App\order;
use Carbon\Carbon;
use DB;  


class adminmemberController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    //phone users
    public function index()  
    {
        $logo            = DB::table('settings')->value('logo');
        $phoneusers      = member::where('role',0)->where('social_type','phone')->orderBy('id','desc')->get();
        return view('admin.users.index',compact('logo','phoneusers'));
    }

    //facebook users
    public function index2()  
    {
        $logo            = DB::table('settings')->value('logo');
        $facebookusers   = member::where('role',0)->where('social_type','facebook')->orderBy('id','desc')->get();
        return view('admin.users.index2',compact('logo','facebookusers'));
    }

    //google users
    public function index3()  
    {
        $logo            = DB::table('settings')->value('logo');
        $googleusers     = member::where('role',0)->where('social_type','google')->orderBy('id','desc')->get();
        return view('admin.users.index3',compact('logo','googleusers'));
    }

    //google users
    public function index4()  
    {
        $logo                 = DB::table('settings')->value('logo');
        $deliveryrequests     = member::where('role',1)->where('activate',0)->orderBy('id','desc')->get();
        return view('admin.users.index4',compact('logo','deliveryrequests'));
    }

    //google users
    public function index5()  
    {
        $logo                = DB::table('settings')->value('logo');
        $deliverymembers     = member::where('role',1)->where('activate',1)->orderBy('id','desc')->get();
        return view('admin.users.index5',compact('logo','deliverymembers'));
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $logo          = DB::table('settings')->value('logo');
        return view('admin.users.create',compact('logo'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'name'           => 'required',
            'idNo'           => 'required',
            'city'           => 'required',
            'nationality'    => 'required',
            'phone'          => 'required|unique:members',
            'password'       => 'required|min:6',
        ]);

        if($request->email)
        {
            $this->validate($request,[
                'email'  => 'required|email|unique:members',
            ]);
        }
            $data                 = $request->all();
            $data['password']     =  Hash::make($request['password']);
            $data['activate']     = 1;
            $data['social_type']  = 'delivery';
            $data['role']         = 1;
            $data['created_at']   = now();

            if($request->hasFile('vehiclelicense'))
            {
                $this->validate($request,[
                    'vehiclelicense'   => 'required|image',
                ]);

                $image    = $request['vehiclelicense'];
                $filename = 'license'.rand(0,999999).'.'.$image->getClientOriginalExtension();
                $image->move(base_path('users/images/'),$filename);
                $data['vehiclelicense']  = $filename;
            }

            if($request->hasFile('vehicleimage'))
            {
                $this->validate($request,[
                    'vehicleimage'   => 'required|image',
                ]);

                $image    = $request['vehicleimage'];
                $filename = 'vehicleimage'.rand(0,999999).'.'.$image->getClientOriginalExtension();
                $image->move(base_path('users/images/'),$filename);
                $data['vehicleimage']  = $filename;
            }
            $newmember          = member::create($data);
            session()->flash('success','تم إضافة مندوب بنجاح');
            return back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $logo              = DB::table('settings')->value('logo');
        $showuser          = member::findorfail($id);
        $revieworders      = order::where('user_id',$id)->where('status',1)->get();
        $acceptorders      = order::where('user_id',$id)->where('status',2)->get();
        $cancelorders      = order::where('user_id',$id)->where('status',3)->get();
        $finishedorders    = order::where('user_id',$id)->where('status',4)->get();
        $pricetotal        = 0;
        $delivercosttotal  = 0;
        return view('admin.users.show',compact('logo','showuser','revieworders','acceptorders','cancelorders','pricetotal','delivercosttotal','finishedorders'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $eduser           = member::find($id);
        $logo             = DB::table('settings')->value('logo');
        return view('admin.users.edit',compact('logo','eduser'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $upmember = member::find($id);

        if(Input::has('suspensed'))
        {
            if($upmember->suspensed == 0)
            {
                DB::table('members')->where('id',$id)->update(['suspensed' => 1]);
                session()->flash('success','تم تعطيل المندوب بنجاح');
                return back();
            }
            else 
            {
                DB::table('members')->where('id',$id)->update(['suspensed' => 0]);
                session()->flash('success','تم تفعيل المندوب بنجاح');
                return back();
            }
        }
        if(Input::has('activation'))
        {
            $this->validate($request,[
                'password'       => 'required|min:6|same:confirmpassword',  
            ]);

            $upmember->password     =  Hash::make($request['password']);
            $upmember->activate     = 1;
            $upmember->save();
            session()->flash('success','تم تفعيل الحساب بنجاح');
            return back();
        }
        else 
        {
            $this->validate($request,[
                'name'            => 'required',
                'idNo'            => 'required',
                'city'            => 'required',
                'nationality'     => 'required',
                'phone'           => 'required|unique:members,phone,'.$id, 
            ]);

            if($request->email)
            {
                $this->validate($request,[
                    'email'  => 'required|email|unique:members,email,'.$id,
                ]);
            }
    
            $data    = $request->all(); 

            if($request['password'])
            {
                $this->validate($request,[
                  'password'       => 'required|min:6|same:confirmpassword',  
                ]);
                $data['password']  =  Hash::make($request['password']);
            }

            if($request->hasFile('vehiclelicense'))
            {
                $this->validate($request,[
                    'vehiclelicense'   => 'required|image',
                ]);

                $image    = $request['vehiclelicense'];
                $filename = 'license'.rand(0,999999).'.'.$image->getClientOriginalExtension();
                $image->move(base_path('users/images/'),$filename);
                $data['vehiclelicense']  = $filename;
            }

            if($request->hasFile('vehicleimage'))
            {
                $this->validate($request,[
                    'vehicleimage'   => 'required|image',
                ]);

                $image    = $request['vehicleimage'];
                $filename = 'vehicleimage'.rand(0,999999).'.'.$image->getClientOriginalExtension();
                $image->move(base_path('users/images/'),$filename);
                $data['vehicleimage']  = $filename;
            }
            $upmember->update($data);  
            $upmember->save();
            session()->flash('success','تم تعديل بيانات المندوب بنجاح');
            return back();
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $deluser = member::find($id);
        if($deluser)
        {
            order::where('user_id',$id)->delete();
            $deluser->delete();
            session()->flash('success','تم حذف المندوب بنجاح');
        }
        return back();  
    }

}
