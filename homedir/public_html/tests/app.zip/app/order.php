<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class order extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'buyer_id','user_id','order','lat','lng','address','additionaladdress','price','delivercost','status','created_at'
    ];
}
