<?php

namespace App;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

use Illuminate\Database\Eloquent\Model;

class member extends Authenticatable
{
    use Notifiable;
    public $timestamps = false;
    
    protected $fillable = [
        'name', 'phone','email','role','social_type','social_id','city','lat','lng','idNo','plateNo','image','nationality','vehicletype',
        'vehiclemodel','vehicleyear','vehiclelicense','vehicleimage','image','password','firebase_token','forgetcode','registercode',
        'activate','suspensed','remember_token','created_at'
    ];

    protected $hidden = [
        'password', 'remember_token',
    ];
}

